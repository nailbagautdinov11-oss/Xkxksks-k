// Игровые механики: кейсы, инвентарь, апгрейдер, Color Dice, магазин. Всё считается только на сервере.
import { all, get, run, tx } from './db.ts';
import {
  GameError, addGems, addUnit, caseItems, now, randInt, removeUnit, rollWeighted, unitValue,
} from './core.ts';
import {
  DICE_COLORS, DICE_MAX_BET, DICE_MIN_BET, DICE_RTP, MAX_OPEN_COUNT, SELL_RATE, SHOP_MARKUP,
  UNITS, UNIT_MAP, UPGRADE_MAX_CHANCE, UPGRADE_MIN_CHANCE, UPGRADE_RTP, type DiceColorId,
} from './catalog.ts';

// ---------- Кейсы ----------
export function openCases(userId: number, caseId: string, count: number) {
  if (!Number.isInteger(count) || count < 1 || count > MAX_OPEN_COUNT) throw new GameError(`Можно открыть от 1 до ${MAX_OPEN_COUNT} кейсов`);
  return tx(() => {
    const c = get('SELECT * FROM cases WHERE id=?', caseId);
    if (!c) throw new GameError('Кейс не найден', 404);
    if (!c.enabled) throw new GameError('Кейс временно недоступен');
    const items = caseItems(caseId);
    const cost = c.price * count;
    const balance = addGems(userId, -cost, 'case_open', `${c.name} x${count}`);
    const drops: { unit_id: string; value: number }[] = [];
    for (let i = 0; i < count; i++) {
      const it = rollWeighted(items);
      const value = unitValue(it.unit_id);
      addUnit(userId, it.unit_id, 1);
      run('INSERT INTO case_openings(user_id,case_id,unit_id,value,ts) VALUES(?,?,?,?,?)', userId, caseId, it.unit_id, value, now());
      drops.push({ unit_id: it.unit_id, value });
    }
    return { drops, cost, balance };
  });
}

// ---------- Инвентарь ----------
export function inventoryOf(userId: number) {
  return all('SELECT unit_id, qty FROM inventory WHERE user_id=? AND qty>0', userId) as { unit_id: string; qty: number }[];
}

export function sellUnits(userId: number, items: { unit_id: string; qty: number }[]) {
  if (!Array.isArray(items) || items.length === 0 || items.length > 200) throw new GameError('Выберите юниты для продажи');
  return tx(() => {
    let total = 0;
    for (const it of items) {
      if (!it || typeof it.unit_id !== 'string') throw new GameError('Некорректный запрос');
      removeUnit(userId, it.unit_id, it.qty);
      total += Math.floor(unitValue(it.unit_id) * it.qty * SELL_RATE);
    }
    const balance = addGems(userId, total, 'sell', 'Продажа юнитов');
    return { gained: total, balance };
  });
}

// ---------- Апгрейдер ----------
export function upgradeChance(inputValue: number, targetValue: number): number {
  return Math.min(UPGRADE_MAX_CHANCE, (UPGRADE_RTP * inputValue) / targetValue);
}

function normalizeInputs(inputs: any): Map<string, number> {
  if (!Array.isArray(inputs) || inputs.length === 0) throw new GameError('Выберите юниты для апгрейда');
  const m = new Map<string, number>();
  let n = 0;
  for (const it of inputs) {
    if (!it || typeof it.unit_id !== 'string' || !Number.isInteger(it.qty) || it.qty <= 0) throw new GameError('Некорректные юниты');
    n += it.qty;
    m.set(it.unit_id, (m.get(it.unit_id) ?? 0) + it.qty);
  }
  if (n > 50) throw new GameError('Не более 50 юнитов за апгрейд');
  return m;
}

function upgradeCalc(inputs: Map<string, number>, target: string) {
  const t = UNIT_MAP.get(target);
  if (!t) throw new GameError('Выберите целевую награду');
  let v = 0;
  for (const [id, q] of inputs) v += unitValue(id) * q;
  if (t.value <= v) throw new GameError('Цель должна стоить дороже выбранных юнитов');
  const chance = upgradeChance(v, t.value);
  if (chance < UPGRADE_MIN_CHANCE) throw new GameError('Шанс слишком мал (мин. 0.5%)');
  return { inputValue: v, targetValue: t.value, chance };
}

export function upgradePreview(userId: number, inputs: any, target: string) {
  const m = normalizeInputs(inputs);
  for (const [id, q] of m) {
    const r = get('SELECT qty FROM inventory WHERE user_id=? AND unit_id=?', userId, id);
    if (!r || r.qty < q) throw new GameError('У вас нет таких юнитов');
  }
  return upgradeCalc(m, target);
}

export function upgrade(userId: number, inputs: any, target: string) {
  const m = normalizeInputs(inputs);
  return tx(() => {
    const calc = upgradeCalc(m, target);
    for (const [id, q] of m) removeUnit(userId, id, q);
    const roll = randInt(1_000_000) / 1_000_000;
    const success = roll < calc.chance;
    if (success) addUnit(userId, target, 1);
    run('INSERT INTO upgrades(user_id,ts,input_value,inputs,target_unit,chance,roll,success) VALUES(?,?,?,?,?,?,?,?)',
      userId, now(), calc.inputValue, JSON.stringify([...m].map(([unit_id, qty]) => ({ unit_id, qty }))), target, calc.chance, roll, success ? 1 : 0);
    return { ...calc, roll, success, target };
  });
}

export function upgradeHistory(userId: number) {
  return all('SELECT id,ts,input_value,inputs,target_unit,chance,roll,success FROM upgrades WHERE user_id=? ORDER BY id DESC LIMIT 30', userId)
    .map((r) => ({ ...r, inputs: JSON.parse(r.inputs), success: !!r.success }));
}

// ---------- Color Dice ----------
type Eff = 'triple' | 'rainbow_burst' | 'golden_storm';
const TOTAL_W = DICE_COLORS.reduce((a, c) => a + c.weight, 0);

function evalDice(chosen: DiceColorId, dice: DiceColorId[]) {
  const matches = dice.filter((d) => d === chosen || (d === 'rainbow' && chosen !== 'rainbow')).length;
  let raw = matches;
  const effects: Eff[] = [];
  if (matches === 3) { raw += 3; effects.push('triple'); }
  const rb = dice.filter((d) => d === 'rainbow').length;
  if (chosen !== 'rainbow' && rb > 0) { raw += 0.5 * rb; effects.push('rainbow_burst'); }
  if (chosen !== 'gold' && dice.every((d) => d === 'gold')) { raw += 2; effects.push('golden_storm'); }
  return { matches, raw, effects };
}

function buildDiceTable() {
  const ids = DICE_COLORS.map((c) => c.id);
  const table: Record<string, any> = {};
  for (const chosen of ids) {
    let ev = 0;
    const pm = [0, 0, 0, 0];
    for (const a of DICE_COLORS) for (const b of DICE_COLORS) for (const c of DICE_COLORS) {
      const p = (a.weight * b.weight * c.weight) / TOTAL_W ** 3;
      const r = evalDice(chosen, [a.id, b.id, c.id]);
      ev += p * r.raw;
      pm[r.matches] += p;
    }
    const k = DICE_RTP / ev;
    table[chosen] = { k, matchProb: pm, perMatch: k, tripleBonus: 3 * k, burstPerDie: 0.5 * k, goldenStorm: 2 * k };
  }
  return table;
}
const DICE_TABLE = buildDiceTable();

export function diceInfo() {
  return { colors: DICE_COLORS.map((c) => ({ ...c, chance: c.weight / TOTAL_W })), table: DICE_TABLE, minBet: DICE_MIN_BET, maxBet: DICE_MAX_BET, rtp: DICE_RTP };
}

export function rollDice(userId: number, color: string, bet: number) {
  const chosen = DICE_COLORS.find((c) => c.id === color);
  if (!chosen) throw new GameError('Выберите цвет');
  if (!Number.isInteger(bet) || bet < DICE_MIN_BET || bet > DICE_MAX_BET) throw new GameError(`Ставка: ${DICE_MIN_BET}–${DICE_MAX_BET} гемов`);
  return tx(() => {
    addGems(userId, -bet, 'dice_bet', `Color Dice: ${chosen.label}`);
    const dice: DiceColorId[] = [0, 1, 2].map(() => rollWeighted(DICE_COLORS as any as { weight: number; id: DiceColorId }[]).id);
    const ev = evalDice(chosen.id, dice);
    const payout = Math.floor(bet * DICE_TABLE[chosen.id].k * ev.raw);
    let balance = get('SELECT gems FROM users WHERE id=?', userId)!.gems;
    if (payout > 0) balance = addGems(userId, payout, 'dice_win', `Color Dice: ${ev.matches} совп.`);
    run('INSERT INTO dice_rolls(user_id,ts,color,bet,dice,payout,effects) VALUES(?,?,?,?,?,?,?)',
      userId, now(), chosen.id, bet, JSON.stringify(dice), payout, JSON.stringify(ev.effects));
    return { dice, matches: ev.matches, effects: ev.effects, payout, bet, balance };
  });
}

export function diceHistory(userId: number) {
  return all('SELECT id,ts,color,bet,dice,payout,effects FROM dice_rolls WHERE user_id=? ORDER BY id DESC LIMIT 30', userId)
    .map((r) => ({ ...r, dice: JSON.parse(r.dice), effects: JSON.parse(r.effects) }));
}

// ---------- Магазин ----------
function dayRng(seed: string) {
  let h = 2166136261;
  for (const c of seed) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); }
  return () => { h ^= h << 13; h ^= h >>> 17; h ^= h << 5; return (h >>> 0) / 4294967296; };
}

export function shopOffers() {
  const day = new Date().toISOString().slice(0, 10);
  const r = dayRng('shop' + day);
  const pool = UNITS.filter((u) => ['Common', 'Uncommon', 'Rare', 'Epic', 'Legendary'].includes(u.rarity));
  const picks = new Map<string, number>();
  // гарантируем разброс редкостей
  for (const rar of ['Common', 'Uncommon', 'Rare', 'Rare', 'Epic', 'Epic', 'Legendary']) {
    const list = pool.filter((u) => u.rarity === rar && !picks.has(u.id));
    if (list.length) { const u = list[Math.floor(r() * list.length)]; picks.set(u.id, Math.ceil(u.value * SHOP_MARKUP)); }
  }
  return { day, offers: [...picks].map(([unit_id, price]) => ({ unit_id, price })) };
}

export function shopBuy(userId: number, unitId: string) {
  const offer = shopOffers().offers.find((o) => o.unit_id === unitId);
  if (!offer) throw new GameError('Этого предложения сегодня нет');
  return tx(() => {
    const balance = addGems(userId, -offer.price, 'shop_buy', UNIT_MAP.get(unitId)!.name);
    addUnit(userId, unitId, 1);
    return { balance, price: offer.price };
  });
}
