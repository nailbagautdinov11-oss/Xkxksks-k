import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { get, run } from './db.ts';
import { GameError, now, seedCatalog } from './core.ts';
import { userByToken } from './auth.ts';
import { routes, UPLOAD_DIR, type Ctx } from './api.ts';
import { attachWs, parseCookies } from './ws.ts';
import { recoverBattles } from './battles.ts';
import { UNIT_MAP } from './catalog.ts';
import { unitSvg } from './art.ts';

const PORT = Number(process.env.PORT) || 3000;
const SECURE = process.env.COOKIE_SECURE === '1';
const TRUST_PROXY = process.env.TRUST_PROXY === '1';
const PUBLIC = path.join(process.cwd(), 'public');

seedCatalog();
recoverBattles();
run('DELETE FROM requests WHERE ts < ?', now() - 24 * 3600 * 1000);
run('DELETE FROM sessions WHERE expires_at < ?', now());

const MIME: Record<string, string> = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon', '.json': 'application/json',
};

// ---- ограничение частоты запросов ----
const hits = new Map<string, { n: number; reset: number }>();
function limited(key: string, max: number, windowMs: number): boolean {
  const t = Date.now();
  const h = hits.get(key);
  if (!h || h.reset < t) { hits.set(key, { n: 1, reset: t + windowMs }); return false; }
  return ++h.n > max;
}
setInterval(() => { const t = Date.now(); for (const [k, v] of hits) if (v.reset < t) hits.delete(k); }, 60000).unref();

function send(res: http.ServerResponse, status: number, body: any, headers: Record<string, string | string[]> = {}) {
  const isBuf = Buffer.isBuffer(body) || typeof body === 'string';
  const data = isBuf ? body : JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': isBuf ? 'text/plain; charset=utf-8' : 'application/json; charset=utf-8',
    'X-Content-Type-Options': 'nosniff', ...headers,
  });
  res.end(data);
}

function readBody(req: http.IncomingMessage, limit = 2_500_000): Promise<any> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = []; let size = 0;
    req.on('data', (c: Buffer) => { size += c.length; if (size > limit) { reject(new GameError('Слишком большой запрос', 413)); req.destroy(); } else chunks.push(c); });
    req.on('end', () => {
      if (!size) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch { reject(new GameError('Некорректный JSON')); }
    });
    req.on('error', reject);
  });
}

function unitImage(id: string, res: http.ServerResponse) {
  const u = UNIT_MAP.get(id);
  if (!u) return send(res, 404, 'not found');
  for (const ext of ['png', 'jpg', 'webp']) {
    const f = path.join(UPLOAD_DIR, `${id}.${ext}`);
    if (fs.existsSync(f)) {
      res.writeHead(200, { 'Content-Type': MIME['.' + ext], 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' });
      return res.end(fs.readFileSync(f));
    }
  }
  res.writeHead(200, { 'Content-Type': 'image/svg+xml', 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' });
  res.end(unitSvg(u));
}

function serveStatic(urlPath: string, res: http.ServerResponse) {
  let rel = decodeURIComponent(urlPath.split('?')[0]);
  if (rel === '/' || !path.extname(rel)) rel = '/index.html';
  const file = path.normalize(path.join(PUBLIC, rel));
  if (!file.startsWith(PUBLIC + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) return send(res, 404, 'not found');
  const ext = path.extname(file);
  res.writeHead(200, {
    'Content-Type': MIME[ext] || 'application/octet-stream', 'X-Content-Type-Options': 'nosniff',
    'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=300',
  });
  fs.createReadStream(file).pipe(res);
}

const server = http.createServer(async (req, res) => {
  const common = {
    'Content-Security-Policy': "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; connect-src 'self' ws: wss:; media-src 'self' data:; frame-ancestors 'none'; base-uri 'none'",
    'X-Frame-Options': 'DENY', 'Referrer-Policy': 'same-origin',
  };
  const origWrite = res.writeHead.bind(res);
  (res as any).writeHead = (status: number, headers?: any) => origWrite(status, { ...common, ...(headers || {}) });
  try {
    const url = new URL(req.url || '/', 'http://x');
    const ip = (TRUST_PROXY && String(req.headers['x-forwarded-for'] || '').split(',')[0].trim()) || req.socket.remoteAddress || '?';

    if (!url.pathname.startsWith('/api/')) {
      if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'method not allowed');
      const m = url.pathname.match(/^\/unit-img\/([a-z0-9-]+)\.svg$/);
      return m ? unitImage(m[1], res) : serveStatic(url.pathname, res);
    }

    if (limited('g:' + ip, 600, 60000)) return send(res, 429, { error: 'Слишком много запросов' });
    const route = routes.find((r) => r.method === req.method && r.re.test(url.pathname));
    if (!route) return send(res, 404, { error: 'Не найдено' });

    const token = parseCookies(req.headers.cookie).tg_session;
    const user = userByToken(token);
    if (route.auth !== 'none' && !user) return send(res, 401, { error: 'Требуется вход' });
    if (route.auth === 'admin' && !user!.is_admin) return send(res, 403, { error: 'Нет доступа' });

    let body: any = {};
    if (req.method === 'POST') {
      if (!String(req.headers['content-type'] || '').startsWith('application/json')) return send(res, 415, { error: 'Нужен JSON' });
      const host = req.headers.host;
      const origin = req.headers.origin;
      if (origin && new URL(origin).host !== host) return send(res, 403, { error: 'Чужой источник запроса' });
      body = await readBody(req);
    }
    if (url.pathname.startsWith('/api/auth/') && req.method === 'POST' && url.pathname !== '/api/auth/logout') {
      const nk = typeof body?.nick === 'string' ? body.nick.toLowerCase() : '';
      if (limited('a:' + ip, 20, 600000) || (nk && limited('n:' + nk, 10, 600000))) return send(res, 429, { error: 'Слишком много попыток входа. Подождите несколько минут.' });
    }

    let cookie: string | undefined;
    const ctx: Ctx = {
      user, body, token, ip, query: url.searchParams,
      params: (url.pathname.match(route.re) || []).slice(1),
      setCookie: (t) => {
        cookie = t
          ? `tg_session=${t}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${30 * 86400}${SECURE ? '; Secure' : ''}`
          : `tg_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0${SECURE ? '; Secure' : ''}`;
      },
    };

    let result: any;
    if (route.idem) {
      const key = String(req.headers['x-request-id'] || '');
      if (key.length < 8 || key.length > 80) throw new GameError('Отсутствует X-Request-Id');
      const prev = get('SELECT response FROM requests WHERE user_id=? AND key=?', user!.id, key);
      if (prev) return send(res, 200, JSON.parse(prev.response), { 'X-Idempotent-Replay': '1' });
      result = route.h(ctx);
      run('INSERT OR IGNORE INTO requests(user_id,key,ts,response) VALUES(?,?,?,?)', user!.id, key, now(), JSON.stringify(result));
    } else result = route.h(ctx);
    send(res, 200, result, cookie ? { 'Set-Cookie': cookie } : {});
  } catch (e: any) {
    if (e instanceof GameError) return send(res, e.status, { error: e.message });
    console.error(e);
    send(res, 500, { error: 'Внутренняя ошибка сервера' });
  }
});

attachWs(server);
server.listen(PORT, () => {
  console.log(`TOILET GRADER запущен: http://localhost:${PORT}`);
  const admin = get('SELECT 1 FROM users WHERE is_admin=1');
  if (!admin) console.log('⚠ Администратор ещё не создан. Выполните: npm run create-admin');
});
process.on('SIGTERM', () => { server.close(); process.exit(0); });
