import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';

export const DATA_DIR = process.env.DATA_DIR || path.join(process.cwd(), 'data');
fs.mkdirSync(path.join(DATA_DIR, 'uploads', 'units'), { recursive: true });

export const db = new DatabaseSync(path.join(DATA_DIR, 'toilet-grader.db'));
db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000; PRAGMA synchronous=NORMAL;');

db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nick TEXT NOT NULL,
  nick_lower TEXT NOT NULL UNIQUE,
  pass_hash TEXT NOT NULL,
  gems INTEGER NOT NULL DEFAULT 0 CHECK(gems >= 0),
  is_admin INTEGER NOT NULL DEFAULT 0,
  banned INTEGER NOT NULL DEFAULT 0,
  ban_reason TEXT,
  avatar_unit TEXT,
  created_at INTEGER NOT NULL,
  last_login_day TEXT,
  streak INTEGER NOT NULL DEFAULT 0,
  last_daily_day TEXT,
  wins INTEGER NOT NULL DEFAULT 0,
  losses INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS sessions(
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS ledger(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  delta INTEGER NOT NULL,
  balance_after INTEGER NOT NULL,
  reason TEXT NOT NULL,
  note TEXT,
  ts INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS ledger_user ON ledger(user_id, id DESC);
CREATE TABLE IF NOT EXISTS units(
  id TEXT PRIMARY KEY, name TEXT NOT NULL, rarity TEXT NOT NULL, value INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS inventory(
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  unit_id TEXT NOT NULL REFERENCES units(id),
  qty INTEGER NOT NULL CHECK(qty >= 0),
  PRIMARY KEY(user_id, unit_id)
);
CREATE TABLE IF NOT EXISTS cases(
  id TEXT PRIMARY KEY, name TEXT NOT NULL, price INTEGER NOT NULL CHECK(price > 0),
  color TEXT NOT NULL, tagline TEXT NOT NULL, sort INTEGER NOT NULL, enabled INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS case_items(
  case_id TEXT NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  unit_id TEXT NOT NULL REFERENCES units(id),
  weight INTEGER NOT NULL CHECK(weight > 0),
  PRIMARY KEY(case_id, unit_id)
);
CREATE TABLE IF NOT EXISTS case_openings(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, case_id TEXT NOT NULL,
  unit_id TEXT NOT NULL, value INTEGER NOT NULL, ts INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS upgrades(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, ts INTEGER NOT NULL,
  input_value INTEGER NOT NULL, inputs TEXT NOT NULL, target_unit TEXT NOT NULL,
  chance REAL NOT NULL, roll REAL NOT NULL, success INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS upgrades_user ON upgrades(user_id, id DESC);
CREATE TABLE IF NOT EXISTS dice_rolls(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, ts INTEGER NOT NULL,
  color TEXT NOT NULL, bet INTEGER NOT NULL, dice TEXT NOT NULL, payout INTEGER NOT NULL, effects TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS dice_user ON dice_rolls(user_id, id DESC);
CREATE TABLE IF NOT EXISTS battles(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  creator_id INTEGER NOT NULL, mode TEXT NOT NULL, max_players INTEGER NOT NULL,
  case_id TEXT NOT NULL, rounds INTEGER NOT NULL, entry INTEGER NOT NULL,
  status TEXT NOT NULL, created_at INTEGER NOT NULL, started_at INTEGER, finished_at INTEGER,
  rolls TEXT, revealed INTEGER NOT NULL DEFAULT 0, result TEXT
);
CREATE TABLE IF NOT EXISTS battle_players(
  battle_id INTEGER NOT NULL REFERENCES battles(id) ON DELETE CASCADE,
  slot INTEGER NOT NULL, user_id INTEGER, paid_by INTEGER NOT NULL,
  nick TEXT NOT NULL, is_bot INTEGER NOT NULL DEFAULT 0, team INTEGER NOT NULL,
  total_value INTEGER NOT NULL DEFAULT 0, outcome TEXT,
  PRIMARY KEY(battle_id, slot)
);
CREATE INDEX IF NOT EXISTS bp_user ON battle_players(user_id);
CREATE TABLE IF NOT EXISTS announcements(
  id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL, ts INTEGER NOT NULL, active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS admin_log(
  id INTEGER PRIMARY KEY AUTOINCREMENT, admin_id INTEGER NOT NULL, action TEXT NOT NULL, detail TEXT NOT NULL, ts INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS withdrawals(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id),
  game_nick TEXT NOT NULL, kind TEXT NOT NULL, unit_id TEXT, qty INTEGER NOT NULL DEFAULT 0, gems INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending', created_at INTEGER NOT NULL, slot_date TEXT NOT NULL,
  processed_by INTEGER, processed_at INTEGER
);
CREATE INDEX IF NOT EXISTS wd_user ON withdrawals(user_id, id DESC);
CREATE TABLE IF NOT EXISTS requests(
  user_id INTEGER NOT NULL, key TEXT NOT NULL, ts INTEGER NOT NULL, response TEXT NOT NULL,
  PRIMARY KEY(user_id, key)
);
`);

const cache = new Map<string, ReturnType<DatabaseSync['prepare']>>();
function stmt(sql: string) {
  let s = cache.get(sql);
  if (!s) { s = db.prepare(sql); cache.set(sql, s); }
  return s;
}
export type Row = Record<string, any>;
export const get = (sql: string, ...p: any[]): Row | undefined => stmt(sql).get(...p) as Row | undefined;
export const all = (sql: string, ...p: any[]): Row[] => stmt(sql).all(...p) as Row[];
export const run = (sql: string, ...p: any[]) => stmt(sql).run(...p);

let depth = 0;
/** Транзакция (повторно входимая). Любое исключение откатывает всё. */
export function tx<T>(fn: () => T): T {
  if (depth > 0) return fn();
  db.exec('BEGIN IMMEDIATE');
  depth++;
  try {
    const r = fn();
    db.exec('COMMIT');
    return r;
  } catch (e) {
    db.exec('ROLLBACK');
    throw e;
  } finally {
    depth--;
  }
}
