// Батлы: комнаты, escrow взносов, серверные броски, пошаговое раскрытие раундов, выдача наград.
import { all, get, run, tx, type Row } from './db.ts';
import {
  GameError, addGems, addUnit, caseItems, now, rollWeighted, unitValue,
} from './core.ts';
import { WIN_BONUS_RATE, UNIT_MAP } from './catalog.ts';
import { broadcast } from './ws.ts';

export type Mode = '1v1' | '2v2' | 'ffa';
const COUNTDOWN_MS = 3000;
const ROUND_MS = 4500;
const FINISH_MS = 3000;
const BOT_NAMES = ['Bot_Plunger', 'Bot_Flush', 'Bot_Siphon', 'Bot_Valve', 'Bot_Mop', 'Bot_Brush'];

const timers = new Map<number, NodeJS.Timeout>();

function teamOf(mode: Mode, slot: number) {
  if (mode === 'ffa') return slot;
  if (mode === '1v1') return slot; // 0 vs 1
  return slot % 2; // 2v2: слоты 0,2 — команда A; 1,3 — команда B
}

export function createBattle(userId: number, mode: Mode, players: number, caseId: string, rounds: number) {
  if (!['1v1', '2v2', 'ffa'].includes(mode)) throw new GameError('Неверный режим');
  const max = mode === '1v1' ? 2 : mode === '2v2' ? 4 : players;
  if (!Number.isInteger(max) || max < 2 || max > 6 || (mode === 'ffa' && max < 3)) throw new GameError('Для режима «каждый сам за себя» нужно 3–6 игроков');
  if (!Number.isInteger(rounds) || rounds < 1 || rounds > 10) throw new GameError('Раундов от 1 до 10');
  return tx(() => {
    const c = get('SELECT * FROM cases WHERE id=?', caseId);
    if (!c || !c.enabled) throw new GameError('Кейс недоступен');
    const open = get("SELECT COUNT(*) n FROM battles WHERE creator_id=? AND status IN ('waiting','starting')", userId)!.n;
    if (open >= 2) throw new GameError('Нельзя создавать более 2 комнат одновременно');
    const entry = c.price * rounds;
    const u = get('SELECT nick FROM users WHERE id=?', userId)!;
    const r = run('INSERT INTO battles(creator_id,mode,max_players,case_id,rounds,entry,status,created_at) VALUES(?,?,?,?,?,?,?,?)',
      userId, mode, max, caseId, rounds, entry, 'waiting', now());
    const id = Number(r.lastInsertRowid);
    addGems(userId, -entry, 'battle_entry', `Баттл #${id}`);
    run('INSERT INTO battle_players(battle_id,slot,user_id,paid_by,nick,is_bot,team) VALUES(?,?,?,?,?,0,?)',
      id, 0, userId, userId, u.nick, teamOf(mode, 0));
    return id;
  });
}

function freeSlot(b: Row, wantTeam?: number): number {
  const used = new Set(all('SELECT slot FROM battle_players WHERE battle_id=?', b.id).map((r) => r.slot));
  for (let s = 0; s < b.max_players; s++) {
    if (used.has(s)) continue;
    if (wantTeam !== undefined && b.mode === '2v2' && teamOf('2v2', s) !== wantTeam) continue;
    return s;
  }
  return -1;
}

function afterJoin(id: number) {
  const b = get('SELECT * FROM battles WHERE id=?', id)!;
  const n = get('SELECT COUNT(*) n FROM battle_players WHERE battle_id=?', id)!.n;
  if (n >= b.max_players && b.status === 'waiting') {
    run("UPDATE battles SET status='starting' WHERE id=?", id);
    timers.set(id, setTimeout(() => startBattle(id), COUNTDOWN_MS));
  }
  broadcast({ t: 'battle', id });
}

export function joinBattle(userId: number, id: number, team?: number) {
  tx(() => {
    const b = get('SELECT * FROM battles WHERE id=?', id);
    if (!b) throw new GameError('Комната не найдена', 404);
    if (b.status !== 'waiting') throw new GameError('Комната уже закрыта для входа');
    if (get('SELECT 1 FROM battle_players WHERE battle_id=? AND user_id=?', id, userId)) throw new GameError('Вы уже в этой комнате');
    const slot = freeSlot(b, team);
    if (slot < 0) throw new GameError('Нет свободных мест');
    const u = get('SELECT nick FROM users WHERE id=?', userId)!;
    addGems(userId, -b.entry, 'battle_entry', `Баттл #${id}`);
    run('INSERT INTO battle_players(battle_id,slot,user_id,paid_by,nick,is_bot,team) VALUES(?,?,?,?,?,0,?)',
      id, slot, userId, userId, u.nick, teamOf(b.mode, slot));
  });
  afterJoin(id);
}

export function addBot(userId: number, id: number) {
  tx(() => {
    const b = get('SELECT * FROM battles WHERE id=?', id);
    if (!b) throw new GameError('Комната не найдена', 404);
    if (b.creator_id !== userId) throw new GameError('Только создатель может добавлять ботов', 403);
    if (b.status !== 'waiting') throw new GameError('Нельзя добавить бота сейчас');
    const slot = freeSlot(b);
    if (slot < 0) throw new GameError('Нет свободных мест');
    addGems(userId, -b.entry, 'battle_entry', `Бот в баттле #${id}`);
    run('INSERT INTO battle_players(battle_id,slot,user_id,paid_by,nick,is_bot,team) VALUES(?,?,NULL,?,?,1,?)',
      id, slot, userId, BOT_NAMES[slot % BOT_NAMES.length], teamOf(b.mode, slot));
  });
  afterJoin(id);
}

function cancel(id: number, why: string) {
  const b = get('SELECT * FROM battles WHERE id=?', id)!;
  for (const p of all('SELECT * FROM battle_players WHERE battle_id=?', id)) {
    addGems(p.paid_by, b.entry, 'battle_refund', `Баттл #${id}: ${why}`);
  }
  run("UPDATE battles SET status='cancelled', finished_at=? WHERE id=?", now(), id);
}

export function leaveBattle(userId: number, id: number) {
  tx(() => {
    const b = get('SELECT * FROM battles WHERE id=?', id);
    if (!b) throw new GameError('Комната не найдена', 404);
    if (b.status !== 'waiting') throw new GameError('Выйти уже нельзя');
    if (b.creator_id === userId) { cancel(id, 'создатель закрыл комнату'); return; }
    const p = get('SELECT * FROM battle_players WHERE battle_id=? AND user_id=?', id, userId);
    if (!p) throw new GameError('Вы не в этой комнате');
    run('DELETE FROM battle_players WHERE battle_id=? AND slot=?', id, p.slot);
    addGems(userId, b.entry, 'battle_refund', `Баттл #${id}: выход`);
  });
  broadcast({ t: 'battle', id });
}

function startBattle(id: number) {
  try {
    tx(() => {
      const b = get('SELECT * FROM battles WHERE id=?', id);
      if (!b || b.status !== 'starting') return;
      const items = caseItems(b.case_id);
      const players = all('SELECT slot FROM battle_players WHERE battle_id=? ORDER BY slot', id);
      const rolls: { slot: number; unit_id: string; value: number }[][] = [];
      for (let r = 0; r < b.rounds; r++) {
        rolls.push(players.map((p) => {
          const it = rollWeighted(items);
          return { slot: p.slot, unit_id: it.unit_id, value: unitValue(it.unit_id) };
        }));
      }
      run("UPDATE battles SET status='running', rolls=?, revealed=0, started_at=? WHERE id=?", JSON.stringify(rolls), now(), id);
    });
  } catch (e) { console.error('startBattle', e); return; }
  broadcast({ t: 'battle', id });
  scheduleReveal(id);
}

function scheduleReveal(id: number) {
  const b = get('SELECT * FROM battles WHERE id=?', id);
  if (!b || b.status !== 'running') return;
  const step = () => {
    const cur = get('SELECT revealed, rounds, status FROM battles WHERE id=?', id);
    if (!cur || cur.status !== 'running') return;
    if (cur.revealed < cur.rounds) {
      run('UPDATE battles SET revealed=revealed+1 WHERE id=?', id);
      broadcast({ t: 'battle', id });
      timers.set(id, setTimeout(step, cur.revealed + 1 < cur.rounds ? ROUND_MS : ROUND_MS + FINISH_MS));
    } else {
      try { settle(id); } catch (e) { console.error('settle', e); }
      broadcast({ t: 'battle', id });
      broadcast({ t: 'lobby' });
    }
  };
  timers.set(id, setTimeout(step, 1200));
}

export function settle(id: number) {
  tx(() => {
    const b = get('SELECT * FROM battles WHERE id=?', id)!;
    if (b.status !== 'running') return;
    const rolls: { slot: number; unit_id: string; value: number }[][] = JSON.parse(b.rolls);
    const players = all('SELECT * FROM battle_players WHERE battle_id=? ORDER BY slot', id);
    const totals = new Map<number, number>();
    for (const p of players) totals.set(p.slot, 0);
    for (const round of rolls) for (const d of round) totals.set(d.slot, (totals.get(d.slot) ?? 0) + d.value);
    const teamTotals = new Map<number, number>();
    for (const p of players) teamTotals.set(p.team, (teamTotals.get(p.team) ?? 0) + totals.get(p.slot)!);
    const best = Math.max(...teamTotals.values());
    const winnerTeams = [...teamTotals].filter(([, v]) => v === best).map(([t]) => t);
    const draw = winnerTeams.length > 1;
    const allDrops = rolls.flat();

    // распределение наград
    const gets = new Map<number, { unit_id: string; value: number }[]>();
    for (const p of players) gets.set(p.slot, []);
    if (draw) {
      for (const d of allDrops) gets.get(d.slot)!.push(d); // каждый забирает свои
    } else {
      const winners = players.filter((p) => p.team === winnerTeams[0]);
      const sorted = [...allDrops].sort((a, c) => c.value - a.value);
      sorted.forEach((d, i) => gets.get(winners[i % winners.length].slot)!.push(d));
    }
    const bonus = Math.round(b.entry * WIN_BONUS_RATE);
    for (const p of players) {
      const win = !draw && p.team === winnerTeams[0];
      run('UPDATE battle_players SET total_value=?, outcome=? WHERE battle_id=? AND slot=?',
        totals.get(p.slot)!, draw ? 'draw' : win ? 'win' : 'lose', id, p.slot);
      if (p.user_id) {
        for (const d of gets.get(p.slot)!) addUnit(p.user_id, d.unit_id, 1);
        if (win) {
          run('UPDATE users SET wins=wins+1 WHERE id=?', p.user_id);
          if (bonus > 0) addGems(p.user_id, bonus, 'battle_win', `Награда за победу в баттле #${id}`);
        } else if (!draw) run('UPDATE users SET losses=losses+1 WHERE id=?', p.user_id);
      } else if (win && p.is_bot) {
        // выигрыш бота достаётся оплатившему его создателю комнаты
        for (const d of gets.get(p.slot)!) addUnit(p.paid_by, d.unit_id, 1);
      }
    }
    const result = {
      draw, winnerTeams, totals: Object.fromEntries(totals),
      gets: Object.fromEntries([...gets].map(([s, l]) => [s, l])),
    };
    run("UPDATE battles SET status='done', finished_at=?, result=? WHERE id=?", now(), JSON.stringify(result), id);
  });
}

export function battleView(id: number) {
  const b = get('SELECT b.*, c.name case_name, c.color case_color, c.price case_price FROM battles b JOIN cases c ON c.id=b.case_id WHERE b.id=?', id);
  if (!b) return null;
  const players = all('SELECT bp.*, u.avatar_unit FROM battle_players bp LEFT JOIN users u ON u.id=bp.user_id WHERE bp.battle_id=? ORDER BY slot', id);
  let rolls: any[] = [];
  const revealedRounds = b.revealed;
  if (b.rolls) rolls = (JSON.parse(b.rolls) as any[]).slice(0, b.status === 'done' ? b.rounds : revealedRounds);
  const totals: Record<number, number> = {};
  for (const r of rolls) for (const d of r) totals[d.slot] = (totals[d.slot] ?? 0) + d.value;
  return {
    id: b.id, mode: b.mode, maxPlayers: b.max_players, rounds: b.rounds, entry: b.entry, status: b.status,
    caseId: b.case_id, caseName: b.case_name, caseColor: b.case_color, creatorId: b.creator_id,
    createdAt: b.created_at, startedAt: b.started_at, finishedAt: b.finished_at, revealed: revealedRounds,
    players: players.map((p) => ({
      slot: p.slot, userId: p.user_id, nick: p.nick, isBot: !!p.is_bot, team: p.team,
      avatarUnit: p.avatar_unit, total: totals[p.slot] ?? 0, outcome: b.status === 'done' ? p.outcome : null,
    })),
    rolls,
    result: b.status === 'done' && b.result ? JSON.parse(b.result) : null,
  };
}

export function lobby(userId: number) {
  const open = all("SELECT id FROM battles WHERE status IN ('waiting','starting','running') ORDER BY id DESC LIMIT 40").map((r) => battleView(r.id));
  const mine = all(`SELECT DISTINCT battle_id id FROM battle_players WHERE user_id=? ORDER BY battle_id DESC LIMIT 30`, userId)
    .map((r) => battleView(r.id)).filter((b) => b && ['done', 'cancelled'].includes(b.status));
  return { open, history: mine };
}

/** Вызывается при старте сервера: незавершённые бои восстанавливаются безопасно. */
export function recoverBattles() {
  for (const b of all("SELECT id, status FROM battles WHERE status IN ('waiting','starting','running')")) {
    try {
      if (b.status === 'running') { run('UPDATE battles SET revealed=rounds WHERE id=?', b.id); settle(b.id); }
      else tx(() => cancel(b.id, 'сервер перезапущен'));
    } catch (e) { console.error('recover', b.id, e); }
  }
}
export { UNIT_MAP };
