import crypto from 'node:crypto';
import { get, run, tx, type Row } from './db.ts';
import { GameError, addGems, now, today } from './core.ts';
import { DAILY_REWARDS, LOGIN_BONUS, START_GEMS } from './catalog.ts';

export const ADMIN_NICK = (process.env.ADMIN_NICK || 'Artyom_Topchik29').trim();
export const RESERVED = new Set([ADMIN_NICK.toLowerCase(), 'admin', 'administrator', 'system', 'moderator', 'toilet_grader']);

const SESSION_MS = 30 * 24 * 3600 * 1000;

export function hashPassword(pw: string): string {
  const salt = crypto.randomBytes(16);
  const key = crypto.scryptSync(pw, salt, 64, { N: 16384, r: 8, p: 1 });
  return `scrypt$16384$8$1$${salt.toString('hex')}$${key.toString('hex')}`;
}

export function verifyPassword(pw: string, stored: string): boolean {
  const [alg, N, r, p, saltHex, keyHex] = stored.split('$');
  if (alg !== 'scrypt') return false;
  const key = crypto.scryptSync(pw, Buffer.from(saltHex, 'hex'), 64, { N: +N, r: +r, p: +p });
  const exp = Buffer.from(keyHex, 'hex');
  return exp.length === key.length && crypto.timingSafeEqual(exp, key);
}

const sha = (s: string) => crypto.createHash('sha256').update(s).digest('hex');

export function createSession(userId: number): string {
  const token = crypto.randomBytes(32).toString('base64url');
  run('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)', sha(token), userId, now() + SESSION_MS);
  return token;
}

export function destroySession(token: string) { run('DELETE FROM sessions WHERE token_hash=?', sha(token)); }

/** Возвращает пользователя по токену. Права администратора берутся ТОЛЬКО из БД. */
export function userByToken(token: string | undefined): Row | undefined {
  if (!token) return undefined;
  const s = get('SELECT user_id, expires_at FROM sessions WHERE token_hash=?', sha(token));
  if (!s || s.expires_at < now()) return undefined;
  const u = get('SELECT * FROM users WHERE id=?', s.user_id);
  if (!u || u.banned) return undefined;
  return u;
}

export function validateNick(nick: unknown): string {
  if (typeof nick !== 'string') throw new GameError('Введите ник');
  const n = nick.trim();
  if (!/^[A-Za-z0-9_]{3,20}$/.test(n)) throw new GameError('Ник: 3–20 символов, латиница, цифры и _');
  return n;
}

export function validatePassword(pw: unknown): string {
  if (typeof pw !== 'string' || pw.length < 8 || pw.length > 100) throw new GameError('Пароль: от 8 до 100 символов');
  return pw;
}

export function register(nickRaw: unknown, pwRaw: unknown): Row {
  const nick = validateNick(nickRaw);
  const pw = validatePassword(pwRaw);
  if (RESERVED.has(nick.toLowerCase())) throw new GameError('Этот ник зарезервирован');
  const hash = hashPassword(pw);
  return tx(() => {
    if (get('SELECT 1 FROM users WHERE nick_lower=?', nick.toLowerCase())) throw new GameError('Ник уже занят');
    const r = run('INSERT INTO users(nick,nick_lower,pass_hash,gems,created_at) VALUES(?,?,?,0,?)',
      nick, nick.toLowerCase(), hash, now());
    const id = Number(r.lastInsertRowid);
    addGems(id, START_GEMS, 'start', 'Стартовый бонус');
    return get('SELECT * FROM users WHERE id=?', id)!;
  });
}

const DUMMY = hashPassword('dummy-password-for-timing');

export function login(nickRaw: unknown, pwRaw: unknown): Row {
  const nick = typeof nickRaw === 'string' ? nickRaw.trim() : '';
  const pw = typeof pwRaw === 'string' ? pwRaw : '';
  const u = get('SELECT * FROM users WHERE nick_lower=?', nick.toLowerCase());
  const ok = verifyPassword(pw, u ? u.pass_hash : DUMMY);
  if (!u || !ok) throw new GameError('Неверный ник или пароль', 401);
  if (u.banned) throw new GameError(`Аккаунт заблокирован${u.ban_reason ? ': ' + u.ban_reason : ''}`, 403);
  return u;
}

/** Бонус за вход: один раз за календарный день (UTC). */
export function applyLoginBonus(userId: number): number {
  return tx(() => {
    const u = get('SELECT last_login_day FROM users WHERE id=?', userId)!;
    const d = today();
    if (u.last_login_day === d) return 0;
    run('UPDATE users SET last_login_day=? WHERE id=?', d, userId);
    addGems(userId, LOGIN_BONUS, 'login_bonus', 'Бонус за вход');
    return LOGIN_BONUS;
  });
}

export function dailyStatus(u: Row) {
  const d = today();
  const y = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
  const claimedToday = u.last_daily_day === d;
  const streakAlive = u.last_daily_day === d || u.last_daily_day === y;
  const curStreak = streakAlive ? u.streak : 0;
  const nextDay = claimedToday ? curStreak % DAILY_REWARDS.length : curStreak % DAILY_REWARDS.length;
  return { claimedToday, streak: curStreak, nextIndex: nextDay, rewards: DAILY_REWARDS };
}

export function claimDaily(userId: number) {
  return tx(() => {
    const u = get('SELECT * FROM users WHERE id=?', userId)!;
    const st = dailyStatus(u);
    if (st.claimedToday) throw new GameError('Ежедневная награда уже получена');
    const newStreak = st.streak + 1;
    const reward = DAILY_REWARDS[(newStreak - 1) % DAILY_REWARDS.length];
    run('UPDATE users SET streak=?, last_daily_day=? WHERE id=?', newStreak, today(), userId);
    addGems(userId, reward, 'daily', `Ежедневная награда, день ${newStreak}`);
    return { reward, streak: newStreak };
  });
}
