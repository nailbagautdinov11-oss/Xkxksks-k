import fs from 'node:fs';
import path from 'node:path';
import { all, get, run, tx, type Row, DATA_DIR } from './db.ts';
import { GameError, addGems, addUnit, caseEv, caseItems, now, publicUser } from './core.ts';
import {
  CASES, DAILY_REWARDS, LOGIN_BONUS, MAX_OPEN_COUNT, RARITY_META, RARITIES, SELL_RATE, SHOP_MARKUP, UNITS, UNIT_MAP,
  UPGRADE_MAX_CHANCE, UPGRADE_MIN_CHANCE, UPGRADE_RTP,
} from './catalog.ts';
import {
  applyLoginBonus, claimDaily, createSession, dailyStatus, destroySession, login, register,
} from './auth.ts';
import * as G from './games.ts';
import * as B from './battles.ts';
import { broadcast, kick } from './ws.ts';
import * as W from './withdraw.ts';

export interface Ctx {
  user: Row | undefined; body: any; params: string[]; query: URLSearchParams; ip: string;
  setCookie: (token: string | null) => void; token?: string;
}
type Handler = (c: Ctx) => any;
interface Route { method: string; re: RegExp; auth: 'none' | 'user' | 'admin'; idem: boolean; h: Handler }
export const routes: Route[] = [];

function def(method: 'GET' | 'POST', p: string, auth: Route['auth'], h: Handler, idem = false) {
  routes.push({ method, re: new RegExp('^' + p.replace(/:[a-z]+/g, '([^/]+)') + '$'), auth, idem, h });
}
const int = (v: any, name = 'значение') => {
  if (!Number.isInteger(v)) throw new GameError(`Некорректное ${name}`);
  return v as number;
};
const str = (v: any, name: string, max = 200) => {
  if (typeof v !== 'string' || !v.trim() || v.length > max) throw new GameError(`Некорректное поле: ${name}`);
  return v.trim();
};

// ---------------- Авторизация ----------------
def('POST', '/api/auth/register', 'none', (c) => {
  const u = register(c.body?.nick, c.body?.password);
  c.setCookie(createSession(u.id));
  const bonus = applyLoginBonus(u.id);
  return { user: publicUser(get('SELECT * FROM users WHERE id=?', u.id)!), loginBonus: bonus };
});
def('POST', '/api/auth/login', 'none', (c) => {
  const u = login(c.body?.nick, c.body?.password);
  c.setCookie(createSession(u.id));
  const bonus = applyLoginBonus(u.id);
  return { user: publicUser(get('SELECT * FROM users WHERE id=?', u.id)!), loginBonus: bonus };
});
def('POST', '/api/auth/logout', 'none', (c) => {
  if (c.token) destroySession(c.token);
  c.setCookie(null);
  return { ok: true };
});
def('GET', '/api/me', 'user', (c) => {
  const u = get('SELECT * FROM users WHERE id=?', c.user!.id)!;
  return { user: publicUser(u), daily: dailyStatus(u) };
});

// ---------------- Каталог ----------------
def('GET', '/api/catalog', 'user', () => {
  const cases = all('SELECT * FROM cases ORDER BY sort, id').map((c) => {
    const items = caseItems(c.id);
    const total = items.reduce((a, b) => a + b.weight, 0);
    return {
      id: c.id, name: c.name, price: c.price, color: c.color, tagline: c.tagline, enabled: !!c.enabled,
      ev: Math.round(caseEv(c.id)),
      items: items.map((i) => ({ unit_id: i.unit_id, weight: i.weight, chance: i.weight / total }))
        .sort((a, b) => b.chance - a.chance),
    };
  });
  return {
    units: UNITS.map((u) => ({ id: u.id, name: u.name, rarity: u.rarity, value: u.value, desc: u.desc })),
    rarities: RARITIES.map((r) => ({ id: r, ...RARITY_META[r] })),
    cases,
    config: {
      sellRate: SELL_RATE, shopMarkup: SHOP_MARKUP, maxOpen: MAX_OPEN_COUNT, upgradeRtp: UPGRADE_RTP,
      upgradeMaxChance: UPGRADE_MAX_CHANCE, upgradeMinChance: UPGRADE_MIN_CHANCE, loginBonus: LOGIN_BONUS, dailyRewards: DAILY_REWARDS,
    },
  };
});

// ---------------- Награды / гемы ----------------
def('POST', '/api/daily/claim', 'user', (c) => claimDaily(c.user!.id), true);
def('GET', '/api/ledger', 'user', (c) => {
  const limit = Math.min(200, Math.max(1, Number(c.query.get('limit')) || 50));
  return { items: all('SELECT id,delta,balance_after,reason,note,ts FROM ledger WHERE user_id=? ORDER BY id DESC LIMIT ?', c.user!.id, limit) };
});

// ---------------- Кейсы / инвентарь ----------------
def('POST', '/api/cases/open', 'user', (c) => G.openCases(c.user!.id, String(c.body?.caseId), c.body?.count ?? 1), true);
def('GET', '/api/inventory', 'user', (c) => ({ items: G.inventoryOf(c.user!.id) }));
def('POST', '/api/inventory/sell', 'user', (c) => G.sellUnits(c.user!.id, c.body?.items), true);

// ---------------- Апгрейдер ----------------
def('POST', '/api/upgrade/preview', 'user', (c) => G.upgradePreview(c.user!.id, c.body?.inputs, String(c.body?.target)));
def('POST', '/api/upgrade', 'user', (c) => G.upgrade(c.user!.id, c.body?.inputs, String(c.body?.target)), true);
def('GET', '/api/upgrade/history', 'user', (c) => ({ items: G.upgradeHistory(c.user!.id) }));

// ---------------- Color Dice ----------------
def('GET', '/api/dice', 'user', () => G.diceInfo());
def('POST', '/api/dice/roll', 'user', (c) => G.rollDice(c.user!.id, String(c.body?.color), c.body?.bet), true);
def('GET', '/api/dice/history', 'user', (c) => ({ items: G.diceHistory(c.user!.id) }));

// ---------------- Магазин ----------------
def('GET', '/api/shop', 'user', () => G.shopOffers());
def('POST', '/api/shop/buy', 'user', (c) => G.shopBuy(c.user!.id, String(c.body?.unit_id)), true);

// ---------------- Батлы ----------------
def('GET', '/api/battles', 'user', (c) => B.lobby(c.user!.id));
def('GET', '/api/battles/:id', 'user', (c) => {
  const v = B.battleView(Number(c.params[0]));
  if (!v) throw new GameError('Комната не найдена', 404);
  return v;
});
def('POST', '/api/battles/create', 'user', (c) => {
  const id = B.createBattle(c.user!.id, c.body?.mode, c.body?.players ?? 0, String(c.body?.caseId), c.body?.rounds);
  broadcast({ t: 'lobby' });
  return { id };
}, true);
def('POST', '/api/battles/:id/join', 'user', (c) => { B.joinBattle(c.user!.id, Number(c.params[0]), c.body?.team); broadcast({ t: 'lobby' }); return { ok: true }; }, true);
def('POST', '/api/battles/:id/bot', 'user', (c) => { B.addBot(c.user!.id, Number(c.params[0])); broadcast({ t: 'lobby' }); return { ok: true }; }, true);
def('POST', '/api/battles/:id/leave', 'user', (c) => { B.leaveBattle(c.user!.id, Number(c.params[0])); broadcast({ t: 'lobby' }); return { ok: true }; }, true);

// ---------------- Профиль / лидерборд ----------------
def('POST', '/api/profile/avatar', 'user', (c) => {
  const id = String(c.body?.unit_id);
  if (!get('SELECT 1 FROM inventory WHERE user_id=? AND unit_id=? AND qty>0', c.user!.id, id)) throw new GameError('У вас нет этого юнита');
  run('UPDATE users SET avatar_unit=? WHERE id=?', id, c.user!.id);
  return { ok: true };
});
def('GET', '/api/profile', 'user', (c) => {
  const id = c.user!.id;
  const u = get('SELECT * FROM users WHERE id=?', id)!;
  const inv = G.inventoryOf(id);
  const count = inv.reduce((a, b) => a + b.qty, 0);
  const worth = inv.reduce((a, b) => a + b.qty * UNIT_MAP.get(b.unit_id)!.value, 0);
  const best = inv.map((i) => UNIT_MAP.get(i.unit_id)!).sort((a, b) => b.value - a.value)[0];
  const opens = get('SELECT COUNT(*) n FROM case_openings WHERE user_id=?', id)!.n;
  const ups = get('SELECT COUNT(*) n, SUM(success) s FROM upgrades WHERE user_id=?', id)!;
  return {
    user: publicUser(u), unitCount: count, uniqueUnits: inv.length, collectionValue: worth,
    bestUnit: best ? { id: best.id, name: best.name, rarity: best.rarity, value: best.value } : null,
    casesOpened: opens, upgrades: { total: ups.n, success: ups.s ?? 0 },
    battleHistory: B.lobby(id).history,
  };
});
def('GET', '/api/leaderboard', 'user', () => ({
  richest: all('SELECT nick, gems score, avatar_unit FROM users WHERE banned=0 ORDER BY gems DESC LIMIT 20'),
  wins: all('SELECT nick, wins score, losses, avatar_unit FROM users WHERE banned=0 AND wins>0 ORDER BY wins DESC LIMIT 20'),
  collections: all(`SELECT u.nick, u.avatar_unit, SUM(i.qty*un.value) score FROM users u
    JOIN inventory i ON i.user_id=u.id JOIN units un ON un.id=i.unit_id WHERE u.banned=0
    GROUP BY u.id ORDER BY score DESC LIMIT 20`),
  upgrades: all(`SELECT u.nick, up.target_unit unit_id, un.value score, up.chance FROM upgrades up
    JOIN users u ON u.id=up.user_id JOIN units un ON un.id=up.target_unit
    WHERE up.success=1 AND u.banned=0 ORDER BY un.value DESC, up.chance ASC LIMIT 20`),
}));
def('GET', '/api/announcements', 'user', () => ({
  items: all('SELECT id,text,ts FROM announcements WHERE active=1 ORDER BY id DESC LIMIT 5'),
}));

// ---------------- Вывод ----------------
def('POST', '/api/withdraw', 'user', (c) => W.createWithdrawal(c.user!.id, c.body), true);
def('GET', '/api/withdraw', 'user', (c) => ({ items: W.myWithdrawals(c.user!.id), slot: W.nextSlot() }));
def('GET', '/api/admin/withdrawals', 'admin', () => ({ items: W.allWithdrawals(), slot: W.nextSlot() }));
def('POST', '/api/admin/withdrawals/resolve', 'admin', (c) => {
  const r = W.resolveWithdrawal(c.user!.id, int(c.body?.id, 'id'), c.body?.action);
  alog(c, 'withdraw_' + c.body.action, { id: c.body.id });
  return r;
}, true);

// ---------------- Админ-панель (проверка прав — только на сервере, по БД) ----------------
function alog(c: Ctx, action: string, detail: object) {
  run('INSERT INTO admin_log(admin_id,action,detail,ts) VALUES(?,?,?,?)', c.user!.id, action, JSON.stringify(detail), now());
}
def('GET', '/api/admin/users', 'admin', (c) => {
  const q = (c.query.get('q') || '').toLowerCase().replace(/[%_]/g, '');
  return {
    items: all(`SELECT u.id,u.nick,u.gems,u.banned,u.ban_reason,u.is_admin,u.wins,u.losses,u.created_at,
      COALESCE((SELECT SUM(qty) FROM inventory WHERE user_id=u.id),0) units,
      COALESCE((SELECT SUM(i.qty*un.value) FROM inventory i JOIN units un ON un.id=i.unit_id WHERE i.user_id=u.id),0) worth
      FROM users u WHERE u.nick_lower LIKE ? ORDER BY u.id DESC LIMIT 100`, `%${q}%`),
  };
});
def('POST', '/api/admin/gems', 'admin', (c) => {
  const userId = int(c.body?.userId, 'id'); const amount = int(c.body?.amount, 'количество');
  if (amount === 0 || Math.abs(amount) > 1_000_000_000) throw new GameError('Сумма вне допустимых пределов');
  const reason = typeof c.body?.reason === 'string' ? c.body.reason.slice(0, 120) : '';
  return tx(() => {
    const t = get('SELECT nick FROM users WHERE id=?', userId);
    if (!t) throw new GameError('Игрок не найден', 404);
    const balance = addGems(userId, amount, amount > 0 ? 'admin_grant' : 'admin_take', `${c.user!.nick}: ${reason}`);
    alog(c, amount > 0 ? 'grant_gems' : 'take_gems', { userId, nick: t.nick, amount, reason });
    return { balance };
  });
}, true);
def('POST', '/api/admin/give-unit', 'admin', (c) => {
  const userId = int(c.body?.userId, 'id'); const qty = int(c.body?.qty, 'количество');
  const unitId = str(c.body?.unit_id, 'unit_id');
  if (qty < 1 || qty > 1000) throw new GameError('Количество 1–1000');
  return tx(() => {
    const t = get('SELECT nick FROM users WHERE id=?', userId);
    if (!t) throw new GameError('Игрок не найден', 404);
    addUnit(userId, unitId, qty);
    alog(c, 'give_unit', { userId, nick: t.nick, unitId, qty });
    return { ok: true };
  });
}, true);
def('POST', '/api/admin/ban', 'admin', (c) => {
  const userId = int(c.body?.userId, 'id'); const banned = !!c.body?.banned;
  const t = get('SELECT * FROM users WHERE id=?', userId);
  if (!t) throw new GameError('Игрок не найден', 404);
  if (t.is_admin) throw new GameError('Нельзя блокировать администратора');
  const reason = typeof c.body?.reason === 'string' ? c.body.reason.slice(0, 120) : null;
  tx(() => {
    run('UPDATE users SET banned=?, ban_reason=? WHERE id=?', banned ? 1 : 0, banned ? reason : null, userId);
    if (banned) run('DELETE FROM sessions WHERE user_id=?', userId);
    alog(c, banned ? 'ban' : 'unban', { userId, nick: t.nick, reason });
  });
  if (banned) kick(userId);
  return { ok: true };
});
def('GET', '/api/admin/cases', 'admin', () => ({
  items: all('SELECT * FROM cases ORDER BY sort, id').map((c) => ({
    ...c, enabled: !!c.enabled, ev: Math.round(caseEv(c.id)), items: caseItems(c.id),
  })),
}));
def('POST', '/api/admin/case', 'admin', (c) => {
  const b = c.body || {};
  const id = str(b.id, 'id', 32);
  if (!/^[a-z0-9-]{2,32}$/.test(id)) throw new GameError('id: a-z, 0-9, дефис');
  return tx(() => {
    let cur = get('SELECT * FROM cases WHERE id=?', id);
    if (!cur) {
      const sort = (get('SELECT COALESCE(MAX(sort),0)+1 s FROM cases')!.s) as number;
      run('INSERT INTO cases(id,name,price,color,tagline,sort,enabled) VALUES(?,?,?,?,?,?,0)', id, str(b.name, 'name', 40), 100, '#38bdf8', '', sort);
      cur = get('SELECT * FROM cases WHERE id=?', id)!;
    }
    if (b.name !== undefined) run('UPDATE cases SET name=? WHERE id=?', str(b.name, 'name', 40), id);
    if (b.tagline !== undefined) run('UPDATE cases SET tagline=? WHERE id=?', String(b.tagline).slice(0, 80), id);
    if (b.color !== undefined) {
      if (!/^#[0-9a-fA-F]{6}$/.test(b.color)) throw new GameError('Цвет вида #aabbcc');
      run('UPDATE cases SET color=? WHERE id=?', b.color, id);
    }
    if (b.price !== undefined) {
      const p = int(b.price, 'цена');
      if (p < 1 || p > 1_000_000_000) throw new GameError('Цена вне допустимых пределов');
      run('UPDATE cases SET price=? WHERE id=?', p, id);
    }
    if (b.items !== undefined) {
      if (!Array.isArray(b.items) || b.items.length === 0 || b.items.length > 100) throw new GameError('Нужен список юнитов');
      run('DELETE FROM case_items WHERE case_id=?', id);
      const seen = new Set<string>();
      for (const it of b.items) {
        const w = int(it?.weight, 'вес');
        if (w < 1 || w > 10_000_000 || !UNIT_MAP.has(it.unit_id) || seen.has(it.unit_id)) throw new GameError('Некорректный список юнитов');
        seen.add(it.unit_id);
        run('INSERT INTO case_items(case_id,unit_id,weight) VALUES(?,?,?)', id, it.unit_id, w);
      }
    }
    if (b.enabled !== undefined) {
      if (b.enabled && caseItems(id).length === 0) throw new GameError('Нельзя включить кейс без юнитов');
      run('UPDATE cases SET enabled=? WHERE id=?', b.enabled ? 1 : 0, id);
    }
    alog(c, 'edit_case', { id, ...b });
    return { ev: Math.round(caseEv(id)) };
  });
});
def('POST', '/api/admin/announce', 'admin', (c) => {
  const text = str(c.body?.text, 'text', 300);
  tx(() => { run('INSERT INTO announcements(text,ts) VALUES(?,?)', text, now()); alog(c, 'announce', { text }); });
  broadcast({ t: 'announce', text });
  return { ok: true };
});
def('POST', '/api/admin/announce/delete', 'admin', (c) => {
  run('UPDATE announcements SET active=0 WHERE id=?', int(c.body?.id, 'id'));
  alog(c, 'announce_delete', { id: c.body.id });
  return { ok: true };
});
def('GET', '/api/admin/log', 'admin', (c) => {
  const nick = (c.query.get('nick') || '').toLowerCase();
  const ledger = nick
    ? all(`SELECT l.id,u.nick,l.delta,l.balance_after,l.reason,l.note,l.ts FROM ledger l JOIN users u ON u.id=l.user_id WHERE u.nick_lower=? ORDER BY l.id DESC LIMIT 100`, nick)
    : all(`SELECT l.id,u.nick,l.delta,l.balance_after,l.reason,l.note,l.ts FROM ledger l JOIN users u ON u.id=l.user_id ORDER BY l.id DESC LIMIT 100`);
  const admin = all('SELECT a.id,u.nick,a.action,a.detail,a.ts FROM admin_log a JOIN users u ON u.id=a.admin_id ORDER BY a.id DESC LIMIT 50');
  return { ledger, admin };
});
// Загрузка собственных иллюстраций юнитов (png/jpeg/webp до 1 МБ)
const MAGIC: [string, number[], string][] = [
  ['png', [0x89, 0x50, 0x4e, 0x47], 'png'], ['jpg', [0xff, 0xd8, 0xff], 'jpg'], ['webp', [0x52, 0x49, 0x46, 0x46], 'webp'],
];
export const UPLOAD_DIR = path.join(DATA_DIR, 'uploads', 'units');
def('POST', '/api/admin/unit-image', 'admin', (c) => {
  const unitId = str(c.body?.unit_id, 'unit_id');
  if (!UNIT_MAP.has(unitId)) throw new GameError('Неизвестный юнит');
  const data = str(c.body?.data, 'data', 1_500_000);
  const buf = Buffer.from(data.replace(/^data:[^,]+,/, ''), 'base64');
  if (buf.length < 100 || buf.length > 1_000_000) throw new GameError('Файл до 1 МБ');
  const kind = MAGIC.find(([, m]) => m.every((b, i) => buf[i] === b));
  if (!kind) throw new GameError('Допустимы PNG, JPEG, WebP');
  for (const ext of ['png', 'jpg', 'webp']) fs.rmSync(path.join(UPLOAD_DIR, `${unitId}.${ext}`), { force: true });
  fs.writeFileSync(path.join(UPLOAD_DIR, `${unitId}.${kind[2]}`), buf);
  alog(c, 'unit_image', { unitId, bytes: buf.length });
  return { ok: true };
});
def('POST', '/api/admin/unit-image/reset', 'admin', (c) => {
  const unitId = str(c.body?.unit_id, 'unit_id');
  if (!UNIT_MAP.has(unitId)) throw new GameError('Неизвестный юнит');
  for (const ext of ['png', 'jpg', 'webp']) fs.rmSync(path.join(UPLOAD_DIR, `${unitId}.${ext}`), { force: true });
  alog(c, 'unit_image_reset', { unitId });
  return { ok: true };
});
export { CASES };
