// Заявки на вывод юнитов и гемов. Предмет списывается сразу (escrow); админ выдаёт его вручную в окне 15:00–17:00 (МСК).
import { all, get, run, tx } from './db.ts';
import { GameError, addGems, addUnit, now, removeUnit } from './core.ts';
import { UNIT_MAP } from './catalog.ts';

export const WINDOW = { from: '15:00', to: '17:00', tz: 'Europe/Moscow' };

function mskNow() {
  const p = Object.fromEntries(new Intl.DateTimeFormat('en-CA', { timeZone: WINDOW.tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', hour12: false })
    .formatToParts(new Date()).map((x) => [x.type, x.value]));
  return { y: +p.year, m: +p.month, d: +p.day, h: +p.hour % 24 };
}

/** Ближайшее окно выдачи: сегодня 15–17 (МСК), а если оно уже прошло — завтра. */
export function nextSlot() {
  const t = mskNow();
  const add = t.h >= 17 ? 1 : 0;
  const date = new Date(Date.UTC(t.y, t.m - 1, t.d + add)).toISOString().slice(0, 10);
  return { date, from: WINDOW.from, to: WINDOW.to, tz: 'МСК' };
}

export function createWithdrawal(userId: number, b: any) {
  const nick = typeof b?.nick === 'string' ? b.nick.trim() : '';
  if (!/^[A-Za-z0-9_]{3,20}$/.test(nick)) throw new GameError('Введите ник (3–20 символов: латиница, цифры, _)');
  const kind = b?.kind;
  if (kind !== 'unit' && kind !== 'gems') throw new GameError('Выберите, что выводить');
  return tx(() => {
    if (get("SELECT COUNT(*) n FROM withdrawals WHERE user_id=? AND status='pending'", userId)!.n >= 5) throw new GameError('Не более 5 активных заявок на вывод');
    const slot = nextSlot();
    let unitId: string | null = null, qty = 0, gems = 0;
    if (kind === 'unit') {
      unitId = String(b.unit_id); qty = b.qty;
      if (!UNIT_MAP.has(unitId)) throw new GameError('Неизвестный юнит');
      if (!Number.isInteger(qty) || qty < 1 || qty > 100) throw new GameError('Количество: 1–100');
      removeUnit(userId, unitId, qty);
    } else {
      gems = b.gems;
      if (!Number.isInteger(gems) || gems < 1 || gems > 1_000_000_000) throw new GameError('Некорректное количество гемов');
      addGems(userId, -gems, 'withdraw', `Вывод на ник ${nick}`);
    }
    const r = run('INSERT INTO withdrawals(user_id,game_nick,kind,unit_id,qty,gems,status,created_at,slot_date) VALUES(?,?,?,?,?,?,?,?,?)',
      userId, nick, kind, unitId, qty, gems, 'pending', now(), slot.date);
    return { id: Number(r.lastInsertRowid), slot };
  });
}

const view = (r: any) => ({ id: r.id, nick: r.nick, gameNick: r.game_nick, kind: r.kind, unitId: r.unit_id, qty: r.qty, gems: r.gems, status: r.status, createdAt: r.created_at, slotDate: r.slot_date, from: WINDOW.from, to: WINDOW.to, processedAt: r.processed_at });

export const myWithdrawals = (userId: number) =>
  all('SELECT w.*, u.nick FROM withdrawals w JOIN users u ON u.id=w.user_id WHERE w.user_id=? ORDER BY w.id DESC LIMIT 30', userId).map(view);
export const allWithdrawals = () =>
  all("SELECT w.*, u.nick FROM withdrawals w JOIN users u ON u.id=w.user_id ORDER BY (w.status='pending') DESC, w.id DESC LIMIT 200").map(view);

export function resolveWithdrawal(adminId: number, id: number, action: string) {
  if (action !== 'done' && action !== 'reject') throw new GameError('Неверное действие');
  return tx(() => {
    const w = get('SELECT * FROM withdrawals WHERE id=?', id);
    if (!w) throw new GameError('Заявка не найдена', 404);
    if (w.status !== 'pending') throw new GameError('Заявка уже обработана');
    if (action === 'reject') { // возврат предмета игроку
      if (w.kind === 'unit') addUnit(w.user_id, w.unit_id, w.qty);
      else addGems(w.user_id, w.gems, 'withdraw_refund', `Заявка #${id} отклонена`);
    }
    run('UPDATE withdrawals SET status=?, processed_by=?, processed_at=? WHERE id=?', action === 'done' ? 'done' : 'rejected', adminId, now(), id);
    return { ok: true };
  });
}
