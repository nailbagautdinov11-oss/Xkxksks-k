// Ядро экономики: гемы, инвентарь, генератор случайных чисел, сидирование каталога.
import crypto from 'node:crypto';
import { all, get, run, tx, type Row } from './db.ts';
import {
  CASES, UNITS, UNIT_MAP, RTP, defaultCaseItems, niceRound,
} from './catalog.ts';

export class GameError extends Error {
  status: number;
  constructor(message: string, status = 400) { super(message); this.status = status; }
}

export const now = () => Date.now();
export const today = () => new Date().toISOString().slice(0, 10);

/** Криптостойкое целое в диапазоне [0, max). */
export const randInt = (max: number) => crypto.randomInt(max);

export function addGems(userId: number, delta: number, reason: string, note?: string): number {
  if (!Number.isInteger(delta)) throw new GameError('Некорректная сумма');
  const u = get('SELECT gems FROM users WHERE id=?', userId);
  if (!u) throw new GameError('Игрок не найден', 404);
  const next = u.gems + delta;
  if (next < 0) throw new GameError('Недостаточно гемов');
  run('UPDATE users SET gems=? WHERE id=?', next, userId);
  run('INSERT INTO ledger(user_id,delta,balance_after,reason,note,ts) VALUES(?,?,?,?,?,?)',
    userId, delta, next, reason, note ?? null, now());
  return next;
}

export function addUnit(userId: number, unitId: string, qty: number) {
  if (!UNIT_MAP.has(unitId)) throw new GameError('Неизвестный юнит');
  if (!Number.isInteger(qty) || qty <= 0) throw new GameError('Некорректное количество');
  run(`INSERT INTO inventory(user_id,unit_id,qty) VALUES(?,?,?)
       ON CONFLICT(user_id,unit_id) DO UPDATE SET qty=qty+excluded.qty`, userId, unitId, qty);
}

export function removeUnit(userId: number, unitId: string, qty: number) {
  if (!Number.isInteger(qty) || qty <= 0) throw new GameError('Некорректное количество');
  const r = get('SELECT qty FROM inventory WHERE user_id=? AND unit_id=?', userId, unitId);
  if (!r || r.qty < qty) throw new GameError('У вас нет такого количества юнитов');
  if (r.qty === qty) run('DELETE FROM inventory WHERE user_id=? AND unit_id=?', userId, unitId);
  else run('UPDATE inventory SET qty=qty-? WHERE user_id=? AND unit_id=?', qty, userId, unitId);
}

export function unitValue(id: string): number {
  const u = UNIT_MAP.get(id);
  if (!u) throw new GameError('Неизвестный юнит');
  return u.value;
}

/** Взвешенный выбор: только на сервере, через crypto.randomInt. */
export function rollWeighted<T extends { weight: number }>(items: T[]): T {
  const total = items.reduce((a, b) => a + b.weight, 0);
  if (total <= 0) throw new GameError('Пустая таблица выпадения');
  let r = randInt(total);
  for (const it of items) {
    if (r < it.weight) return it;
    r -= it.weight;
  }
  return items[items.length - 1];
}

export function caseItems(caseId: string): { unit_id: string; weight: number }[] {
  return all('SELECT unit_id, weight FROM case_items WHERE case_id=?', caseId) as any;
}

export function caseEv(caseId: string): number {
  const items = caseItems(caseId);
  const total = items.reduce((a, b) => a + b.weight, 0);
  return items.reduce((a, b) => a + (b.weight / total) * unitValue(b.unit_id), 0);
}

export function seedCatalog() {
  tx(() => {
    for (const u of UNITS) {
      run(`INSERT INTO units(id,name,rarity,value) VALUES(?,?,?,?)
           ON CONFLICT(id) DO UPDATE SET name=excluded.name, rarity=excluded.rarity, value=excluded.value`,
        u.id, u.name, u.rarity, u.value);
    }
    const n = get('SELECT COUNT(*) c FROM cases')!.c;
    if (n === 0) {
      CASES.forEach((c, i) => {
        const items = defaultCaseItems(c);
        const total = items.reduce((a, b) => a + b.weight, 0);
        const ev = items.reduce((a, b) => a + (b.weight / total) * UNIT_MAP.get(b.unit_id)!.value, 0);
        const price = niceRound(ev / RTP);
        run('INSERT INTO cases(id,name,price,color,tagline,sort,enabled) VALUES(?,?,?,?,?,?,1)',
          c.id, c.name, price, c.color, c.tagline, i);
        for (const it of items) run('INSERT INTO case_items(case_id,unit_id,weight) VALUES(?,?,?)', c.id, it.unit_id, it.weight);
      });
    }
  });
}

export function publicUser(u: Row) {
  return {
    id: u.id, nick: u.nick, gems: u.gems, isAdmin: !!u.is_admin, avatarUnit: u.avatar_unit,
    wins: u.wins, losses: u.losses, streak: u.streak, createdAt: u.created_at,
  };
}
