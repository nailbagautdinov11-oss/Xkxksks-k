// Генератор оригинальных SVG-иллюстраций юнитов (персонажи-унитазы).
import { RARITY_META, type UnitDef, type Acc, type Eyes, type Mouth } from './catalog.ts';

function rng(seed: string) {
  let h = 2166136261;
  for (const c of seed) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); }
  return () => {
    h ^= h << 13; h ^= h >>> 17; h ^= h << 5;
    return ((h >>> 0) % 100000) / 100000;
  };
}

const hsl = (h: number, s: number, l: number) => `hsl(${Math.round(h) % 360} ${s}% ${l}%)`;

function accessory(acc: Acc, hue: number): string {
  const gold = '#fbbf24';
  switch (acc) {
    case 'crown':
      return `<path d="M135 78 L150 38 L175 66 L200 28 L225 66 L250 38 L265 78 Z" fill="${gold}" stroke="#b45309" stroke-width="4" stroke-linejoin="round"/>
        <circle cx="200" cy="44" r="6" fill="#ef4444"/><circle cx="152" cy="50" r="4" fill="#38bdf8"/><circle cx="248" cy="50" r="4" fill="#38bdf8"/>`;
    case 'helmet':
      return `<path d="M132 84 Q132 30 200 30 Q268 30 268 84 Z" fill="#94a3b8" stroke="#334155" stroke-width="4"/>
        <rect x="190" y="30" width="20" height="54" fill="#cbd5e1" stroke="#334155" stroke-width="3"/>`;
    case 'wizard':
      return `<path d="M140 84 L200 -10 L262 84 Z" fill="${hsl(hue + 40, 60, 35)}" stroke="#1e1b4b" stroke-width="4" stroke-linejoin="round"/>
        <ellipse cx="200" cy="86" rx="82" ry="12" fill="${hsl(hue + 40, 60, 28)}" stroke="#1e1b4b" stroke-width="4"/>
        <circle cx="200" cy="38" r="7" fill="${gold}"/>`;
    case 'halo':
      return `<ellipse cx="200" cy="34" rx="52" ry="12" fill="none" stroke="${gold}" stroke-width="9"/>
        <ellipse cx="200" cy="34" rx="52" ry="12" fill="none" stroke="#fff7" stroke-width="2"/>`;
    case 'horns':
      return `<path d="M140 80 Q118 40 146 14 Q146 52 168 70 Z" fill="#fca5a5" stroke="#7f1d1d" stroke-width="4" stroke-linejoin="round"/>
        <path d="M260 80 Q282 40 254 14 Q254 52 232 70 Z" fill="#fca5a5" stroke="#7f1d1d" stroke-width="4" stroke-linejoin="round"/>`;
    case 'antenna':
      return `<line x1="200" y1="72" x2="200" y2="22" stroke="#cbd5e1" stroke-width="5"/>
        <circle cx="200" cy="18" r="10" fill="#ef4444" stroke="#7f1d1d" stroke-width="3"/>`;
    case 'headband':
      return `<rect x="130" y="86" width="140" height="16" rx="6" fill="#ef4444" stroke="#7f1d1d" stroke-width="3"/>
        <path d="M268 94 L300 80 M268 96 L304 104" stroke="#ef4444" stroke-width="7" stroke-linecap="round"/>`;
    case 'tophat':
      return `<rect x="156" y="20" width="88" height="62" rx="6" fill="#1f2937" stroke="#000" stroke-width="3"/>
        <rect x="156" y="62" width="88" height="10" fill="#a855f7"/>
        <ellipse cx="200" cy="84" rx="76" ry="9" fill="#111827" stroke="#000" stroke-width="3"/>`;
    case 'pirate':
      return `<path d="M120 88 Q200 -6 280 88 Q200 70 120 88 Z" fill="#111827" stroke="#000" stroke-width="3"/>
        <circle cx="200" cy="52" r="10" fill="#f8fafc"/><path d="M190 64 L210 64 M195 44 L205 60 M205 44 L195 60" stroke="#111827" stroke-width="3"/>`;
    case 'flame':
      return `<path d="M200 -2 Q232 30 218 52 Q250 44 238 84 L162 84 Q150 44 182 52 Q168 30 200 -2 Z" fill="#f97316" stroke="#9a3412" stroke-width="3"/>
        <path d="M200 30 Q218 54 208 78 L192 78 Q182 54 200 30 Z" fill="#fde047"/>`;
    case 'visor':
      return `<rect x="128" y="88" width="144" height="20" rx="10" fill="${hsl(hue + 150, 80, 55)}" opacity=".85" stroke="#0f172a" stroke-width="3"/>`;
    default:
      return '';
  }
}

function eyes(kind: Eyes, hue: number): string {
  const L = 160, Rr = 240, y = 268;
  switch (kind) {
    case 'angry':
      return `<ellipse cx="${L}" cy="${y}" rx="17" ry="15" fill="#fff"/><ellipse cx="${Rr}" cy="${y}" rx="17" ry="15" fill="#fff"/>
        <circle cx="${L + 4}" cy="${y + 2}" r="8" fill="#111"/><circle cx="${Rr - 4}" cy="${y + 2}" r="8" fill="#111"/>
        <path d="M${L - 22} ${y - 26} L${L + 20} ${y - 10}" stroke="#111" stroke-width="7" stroke-linecap="round"/>
        <path d="M${Rr + 22} ${y - 26} L${Rr - 20} ${y - 10}" stroke="#111" stroke-width="7" stroke-linecap="round"/>`;
    case 'cyclops':
      return `<ellipse cx="200" cy="${y}" rx="32" ry="26" fill="#fff" stroke="#111" stroke-width="3"/>
        <circle cx="204" cy="${y + 2}" r="15" fill="${hsl(hue + 120, 80, 50)}"/><circle cx="204" cy="${y + 2}" r="7" fill="#111"/>
        <circle cx="198" cy="${y - 6}" r="4" fill="#fff"/>`;
    case 'visor':
      return `<rect x="128" y="${y - 18}" width="144" height="34" rx="17" fill="#0f172a" stroke="#000" stroke-width="3"/>
        <rect x="140" y="${y - 6}" width="120" height="10" rx="5" fill="${hsl(hue + 150, 100, 60)}"/>`;
    case 'sleepy':
      return `<path d="M${L - 18} ${y} Q${L} ${y + 16} ${L + 18} ${y}" stroke="#111" stroke-width="6" fill="none" stroke-linecap="round"/>
        <path d="M${Rr - 18} ${y} Q${Rr} ${y + 16} ${Rr + 18} ${y}" stroke="#111" stroke-width="6" fill="none" stroke-linecap="round"/>`;
    case 'star':
      return [L, Rr].map((x) =>
        `<path d="M${x} ${y - 20} L${x + 6} ${y - 6} L${x + 21} ${y - 6} L${x + 9} ${y + 4} L${x + 13} ${y + 19} L${x} ${y + 10} L${x - 13} ${y + 19} L${x - 9} ${y + 4} L${x - 21} ${y - 6} L${x - 6} ${y - 6} Z" fill="#fde047" stroke="#a16207" stroke-width="2.5" stroke-linejoin="round"/>`).join('');
    default:
      return `<circle cx="${L}" cy="${y}" r="19" fill="#fff" stroke="#111" stroke-width="3"/><circle cx="${Rr}" cy="${y}" r="19" fill="#fff" stroke="#111" stroke-width="3"/>
        <circle cx="${L + 3}" cy="${y + 2}" r="9" fill="#111"/><circle cx="${Rr - 3}" cy="${y + 2}" r="9" fill="#111"/>
        <circle cx="${L - 2}" cy="${y - 4}" r="3.5" fill="#fff"/><circle cx="${Rr - 8}" cy="${y - 4}" r="3.5" fill="#fff"/>`;
  }
}

function mouth(kind: Mouth): string {
  const y = 308;
  switch (kind) {
    case 'grin':
      return `<path d="M158 ${y - 6} Q200 ${y + 36} 242 ${y - 6} Z" fill="#111" stroke="#111" stroke-width="3" stroke-linejoin="round"/>
        <path d="M170 ${y - 4} L170 ${y + 8} M185 ${y - 3} L185 ${y + 14} M200 ${y - 3} L200 ${y + 16} M215 ${y - 3} L215 ${y + 14} M230 ${y - 4} L230 ${y + 8}" stroke="#fff" stroke-width="5"/>`;
    case 'fang':
      return `<path d="M168 ${y} Q200 ${y + 16} 232 ${y}" stroke="#111" stroke-width="5" fill="none" stroke-linecap="round"/>
        <path d="M178 ${y + 4} L186 ${y + 22} L192 ${y + 8} Z M222 ${y + 4} L214 ${y + 22} L208 ${y + 8} Z" fill="#fff" stroke="#111" stroke-width="2"/>`;
    case 'flat':
      return `<path d="M172 ${y + 6} L228 ${y + 6}" stroke="#111" stroke-width="7" stroke-linecap="round"/>`;
    case 'open':
      return `<ellipse cx="200" cy="${y + 8}" rx="24" ry="18" fill="#111"/><ellipse cx="200" cy="${y + 16}" rx="14" ry="8" fill="#ef4444"/>`;
    default:
      return `<path d="M164 ${y - 2} Q200 ${y + 32} 236 ${y - 2}" stroke="#111" stroke-width="7" fill="none" stroke-linecap="round"/>`;
  }
}

export function unitSvg(u: UnitDef): string {
  const meta = RARITY_META[u.rarity];
  const { hue, acc, eyes: ey, mouth: mo } = u.art;
  const r = rng(u.id);
  const rc = meta.color;
  const rank = meta.order;

  const sparks: string[] = [];
  const n = 8 + rank * 6;
  for (let i = 0; i < n; i++) {
    const x = Math.round(r() * 400), y = Math.round(r() * 400), s = (1 + r() * (1.5 + rank * 0.4)).toFixed(1);
    sparks.push(`<circle cx="${x}" cy="${y}" r="${s}" fill="${rc}" opacity="${(0.25 + r() * 0.6).toFixed(2)}"/>`);
  }
  const rings = Array.from({ length: Math.min(4, 1 + Math.floor(rank / 2)) }, (_, i) =>
    `<circle cx="200" cy="215" r="${150 + i * 22}" fill="none" stroke="${rc}" stroke-opacity="${0.35 - i * 0.07}" stroke-width="${2 + (i === 0 ? 2 : 0)}" ${i % 2 ? 'stroke-dasharray="8 10"' : ''}/>`).join('');

  const body1 = hsl(hue, 55, 92), body2 = hsl(hue, 45, 70), body3 = hsl(hue, 45, 52);
  const glitch = u.rarity === 'Secret'
    ? `<g opacity=".5" transform="translate(7 -3)" fill="#22d3ee"><rect x="60" y="160" width="90" height="8"/><rect x="250" y="210" width="80" height="6"/></g>
       <g opacity=".5" transform="translate(-6 4)" fill="#f43f5e"><rect x="80" y="300" width="70" height="7"/><rect x="240" y="120" width="60" height="6"/></g>` : '';
  const rainbow = u.rarity === 'Exclusive'
    ? `<linearGradient id="rb" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f43f5e"/><stop offset=".25" stop-color="#fbbf24"/><stop offset=".5" stop-color="#4ade80"/><stop offset=".75" stop-color="#38bdf8"/><stop offset="1" stop-color="#a855f7"/></linearGradient>` : '';
  const border = u.rarity === 'Exclusive' ? 'url(#rb)' : rc;

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
<defs>
${rainbow}
<radialGradient id="bg" cx="50%" cy="46%" r="70%"><stop offset="0" stop-color="${rc}" stop-opacity=".55"/><stop offset=".55" stop-color="#14122b"/><stop offset="1" stop-color="#07061a"/></radialGradient>
<linearGradient id="body" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${body1}"/><stop offset=".6" stop-color="${body2}"/><stop offset="1" stop-color="${body3}"/></linearGradient>
<filter id="glow" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="9"/></filter>
</defs>
<rect width="400" height="400" fill="url(#bg)"/>
${sparks.join('')}${rings}
<ellipse cx="200" cy="215" rx="130" ry="150" fill="${rc}" opacity=".18" filter="url(#glow)"/>
${glitch}
<ellipse cx="200" cy="384" rx="120" ry="12" fill="#000" opacity=".35"/>
<path d="M150 338 L250 338 L268 378 L132 378 Z" fill="url(#body)" stroke="#1e1b4b" stroke-width="4" stroke-linejoin="round"/>
<path d="M78 222 Q76 338 200 344 Q324 338 322 222 Z" fill="url(#body)" stroke="#1e1b4b" stroke-width="5" stroke-linejoin="round"/>
<rect x="132" y="74" width="136" height="112" rx="20" fill="url(#body)" stroke="#1e1b4b" stroke-width="5"/>
<rect x="148" y="88" width="104" height="14" rx="7" fill="#fff" opacity=".35"/>
<circle cx="268" cy="120" r="9" fill="${rc}" stroke="#1e1b4b" stroke-width="3"/>
<ellipse cx="200" cy="222" rx="124" ry="32" fill="${body1}" stroke="#1e1b4b" stroke-width="5"/>
<ellipse cx="200" cy="224" rx="98" ry="21" fill="${hsl(hue + 20, 70, 28)}"/>
<ellipse cx="190" cy="220" rx="46" ry="7" fill="#fff" opacity=".2"/>
${eyes(ey, hue)}${mouth(mo)}
${accessory(acc, hue)}
<rect x="3" y="3" width="394" height="394" rx="26" fill="none" stroke="${border}" stroke-width="6" opacity=".9"/>
</svg>`;
}
