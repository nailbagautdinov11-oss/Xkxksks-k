// Каталог оригинальных юнитов, редкостей и кейсов TOILET GRADER.
// Все персонажи придуманы для этой игры; изображения генерируются в server/art.ts.

export type Rarity =
  | 'Common' | 'Uncommon' | 'Rare' | 'Epic' | 'Legendary' | 'Mythic' | 'Secret' | 'Exclusive';

export const RARITIES: Rarity[] = [
  'Common', 'Uncommon', 'Rare', 'Epic', 'Legendary', 'Mythic', 'Secret', 'Exclusive',
];

export const RARITY_META: Record<Rarity, { color: string; label: string; order: number }> = {
  Common: { color: '#9aa4b2', label: 'Обычный', order: 0 },
  Uncommon: { color: '#4ade80', label: 'Необычный', order: 1 },
  Rare: { color: '#38bdf8', label: 'Редкий', order: 2 },
  Epic: { color: '#a855f7', label: 'Эпический', order: 3 },
  Legendary: { color: '#fbbf24', label: 'Легендарный', order: 4 },
  Mythic: { color: '#ef4444', label: 'Мифический', order: 5 },
  Secret: { color: '#22d3ee', label: 'Секретный', order: 6 },
  Exclusive: { color: '#f472b6', label: 'Эксклюзив', order: 7 },
};

export type Acc =
  | 'none' | 'crown' | 'helmet' | 'wizard' | 'halo' | 'horns' | 'antenna'
  | 'headband' | 'tophat' | 'pirate' | 'flame' | 'visor';
export type Eyes = 'round' | 'angry' | 'cyclops' | 'visor' | 'sleepy' | 'star';
export type Mouth = 'smile' | 'grin' | 'fang' | 'flat' | 'open';

export interface UnitDef {
  id: string;
  name: string;
  rarity: Rarity;
  value: number;
  desc: string;
  art: { hue: number; acc: Acc; eyes: Eyes; mouth: Mouth };
}

type Row = [string, string, number, string, number, Acc, Eyes, Mouth];
// [id, name, value, desc, hue, acc, eyes, mouth]
const R = (rarity: Rarity, rows: Row[]): UnitDef[] =>
  rows.map(([id, name, value, desc, hue, acc, eyes, mouth]) => ({
    id, name, rarity, value, desc, art: { hue, acc, eyes, mouth },
  }));

export const UNITS: UnitDef[] = [
  ...R('Common', [
    ['plunger-pup', 'Plunger Pup', 12, 'Преданный щенок с присоской вместо хвоста.', 200, 'none', 'round', 'smile'],
    ['soggy-sponge', 'Soggy Sponge', 18, 'Вечно мокрый, но всегда бодрый.', 55, 'none', 'sleepy', 'flat'],
    ['bubble-bowl', 'Bubble Bowl', 25, 'Пускает пузыри на каждом шагу.', 190, 'antenna', 'round', 'open'],
    ['mini-flush', 'Mini Flush', 32, 'Самый маленький смыв в мире.', 160, 'headband', 'round', 'grin'],
    ['drip-drop', 'Drip Drop', 38, 'Капает на нервы врагам.', 210, 'none', 'sleepy', 'smile'],
    ['paper-roll-pal', 'Paper Roll Pal', 45, 'Разматывается в самый неподходящий момент.', 40, 'headband', 'round', 'smile'],
  ]),
  ...R('Uncommon', [
    ['brush-knight', 'Brush Knight', 70, 'Рыцарь щётки, чистит ряды врагов.', 140, 'helmet', 'angry', 'flat'],
    ['tank-tinkerer', 'Tank Tinkerer', 95, 'Вечно чинит свой бачок.', 25, 'antenna', 'round', 'grin'],
    ['lid-lizard', 'Lid Lizard', 120, 'Прячется под крышкой от всех проблем.', 100, 'horns', 'sleepy', 'fang'],
    ['pipe-pixie', 'Pipe Pixie', 150, 'Маленькая фея водопроводных труб.', 300, 'halo', 'star', 'smile'],
    ['foam-fiend', 'Foam Fiend', 185, 'Взбивает пену до небес.', 180, 'horns', 'angry', 'open'],
    ['valve-vagabond', 'Valve Vagabond', 220, 'Бродяга, открывающий любые вентили.', 20, 'pirate', 'round', 'flat'],
    ['sewer-scout', 'Sewer Scout', 260, 'Разведчик канализационных тоннелей.', 120, 'visor', 'visor', 'smile'],
  ]),
  ...R('Rare', [
    ['gold-seat-scout', 'Gold Seat Scout', 380, 'Сидит на золотом троне разведки.', 48, 'crown', 'round', 'grin'],
    ['flush-ranger', 'Flush Ranger', 470, 'Страж быстрых потоков.', 150, 'headband', 'angry', 'grin'],
    ['mop-monk', 'Mop Monk', 560, 'Медитирует над лужами.', 35, 'halo', 'sleepy', 'smile'],
    ['siphon-sniper', 'Siphon Sniper', 700, 'Попадает точно в слив.', 195, 'visor', 'visor', 'flat'],
    ['whirl-wizard', 'Whirl Wizard', 850, 'Вызывает водовороты заклинаниями.', 260, 'wizard', 'star', 'smile'],
    ['porcelain-pirate', 'Porcelain Pirate', 1000, 'Капитан фарфоровых морей.', 215, 'pirate', 'angry', 'fang'],
    ['bidet-bandit', 'Bidet Bandit', 1250, 'Брызгает точно и без промаха.', 330, 'headband', 'angry', 'grin'],
    ['ceramic-cadet', 'Ceramic Cadet', 1500, 'Кадет академии керамики.', 175, 'helmet', 'round', 'smile'],
  ]),
  ...R('Epic', [
    ['cistern-knight', 'Cistern Knight', 2200, 'Бачок как щит, труба как меч.', 225, 'helmet', 'angry', 'flat'],
    ['vortex-vandal', 'Vortex Vandal', 2900, 'Создаёт хаос в каждом вихре.', 285, 'horns', 'angry', 'fang'],
    ['neon-nozzle', 'Neon Nozzle', 3600, 'Светится в темноте канализации.', 170, 'antenna', 'visor', 'grin'],
    ['tidal-throne', 'Tidal Throne', 4500, 'Трон, управляющий приливами.', 200, 'crown', 'round', 'smile'],
    ['plumber-paladin', 'Plumber Paladin', 5600, 'Святой защитник труб.', 52, 'halo', 'round', 'flat'],
    ['drain-dragonet', 'Drain Dragonet', 7000, 'Маленький дракон из слива.', 10, 'horns', 'cyclops', 'fang'],
    ['chrome-commode', 'Chrome Commode', 8800, 'Сияет как зеркало.', 210, 'visor', 'visor', 'grin'],
    ['septic-samurai', 'Septic Samurai', 11000, 'Путь воина — путь воды.', 350, 'headband', 'angry', 'flat'],
  ]),
  ...R('Legendary', [
    ['royal-flushmaster', 'Royal Flushmaster', 16000, 'Мастер королевского смыва.', 45, 'crown', 'round', 'grin'],
    ['aqua-archon', 'Aqua Archon', 22000, 'Архонт всех вод.', 195, 'halo', 'star', 'smile'],
    ['thunder-tank', 'Thunder Tank', 29000, 'Бачок, полный грома.', 55, 'antenna', 'angry', 'open'],
    ['crystal-cistern', 'Crystal Cistern', 37000, 'Хрустальный бачок древних.', 185, 'crown', 'star', 'smile'],
    ['sewer-sovereign', 'Sewer Sovereign', 48000, 'Владыка подземных каналов.', 130, 'crown', 'angry', 'fang'],
    ['phantom-flusher', 'Phantom Flusher', 62000, 'Смывает, оставаясь невидимым.', 270, 'tophat', 'cyclops', 'flat'],
    ['solar-seat', 'Solar Seat', 80000, 'Сиденье, горящее как звезда.', 30, 'flame', 'round', 'grin'],
  ]),
  ...R('Mythic', [
    ['void-vortex', 'Void Vortex', 130000, 'Втягивает всё, даже свет.', 265, 'horns', 'cyclops', 'open'],
    ['celestial-commode', 'Celestial Commode', 180000, 'Небесный унитаз созвездий.', 215, 'halo', 'star', 'smile'],
    ['abyssal-siphon', 'Abyssal Siphon', 250000, 'Сифон из бездны океана.', 195, 'horns', 'angry', 'fang'],
    ['chaos-cistern', 'Chaos Cistern', 340000, 'Бачок, где живёт хаос.', 0, 'flame', 'angry', 'open'],
    ['prism-porcelain', 'Prism Porcelain', 450000, 'Раскладывает свет на цвета радуги.', 300, 'crown', 'star', 'grin'],
  ]),
  ...R('Secret', [
    ['the-last-flush', 'The Last Flush', 900000, 'Говорят, после него наступит тишина.', 180, 'halo', 'sleepy', 'flat'],
    ['glitch-bowl', 'Glitch Bowl', 1300000, 'Ошибка реальности в форме чаши.', 140, 'antenna', 'cyclops', 'open'],
    ['cosmic-cistern', 'Cosmic Cistern', 1900000, 'Бачок размером с галактику.', 250, 'tophat', 'star', 'smile'],
    ['ancient-aqueduct', 'Ancient Aqueduct', 2800000, 'Первый унитаз цивилизации.', 38, 'crown', 'round', 'flat'],
  ]),
  ...R('Exclusive', [
    ['founders-throne', "Founder's Throne", 6000000, 'Трон основателей Grader.', 45, 'crown', 'star', 'grin'],
    ['golden-plunger', 'Golden Plunger', 9000000, 'Легенда: им открывают любые засоры.', 50, 'flame', 'round', 'smile'],
    ['grader-crown', 'Grader Crown', 15000000, 'Высшая награда Grader.', 320, 'crown', 'cyclops', 'grin'],
  ]),
];

export const UNIT_MAP = new Map(UNITS.map((u) => [u.id, u]));

export interface CaseDef {
  id: string;
  name: string;
  color: string;
  tagline: string;
  // доли шансов по редкостям, в процентах (в сумме 100)
  tiers: Partial<Record<Rarity, number>>;
}

export const RTP = 0.92; // доля возврата кейса (цена вычисляется из матожидания)

export const CASES: CaseDef[] = [
  { id: 'basic', name: 'Basic Case', color: '#9aa4b2', tagline: 'Для первых шагов', tiers: { Common: 70, Uncommon: 25, Rare: 5 } },
  { id: 'rare', name: 'Rare Case', color: '#38bdf8', tagline: 'Редкие находки', tiers: { Uncommon: 45, Rare: 45, Epic: 9, Legendary: 1 } },
  { id: 'epic', name: 'Epic Case', color: '#a855f7', tagline: 'Эпичный улов', tiers: { Rare: 50, Epic: 40, Legendary: 9.5, Mythic: 0.5 } },
  { id: 'legendary', name: 'Legendary Case', color: '#fbbf24', tagline: 'Золотой шанс', tiers: { Epic: 55, Legendary: 38, Mythic: 6.5, Secret: 0.5 } },
  { id: 'mythic', name: 'Mythic Case', color: '#ef4444', tagline: 'Только для смелых', tiers: { Legendary: 60, Mythic: 36, Secret: 4 } },
  { id: 'secret', name: 'Secret Case', color: '#22d3ee', tagline: 'Кто знает, что внутри…', tiers: { Mythic: 70, Secret: 29.5, Exclusive: 0.5 } },
];

/** Веса (целые, сумма ≈ 100000) для юнитов кейса: внутри редкости обратно пропорциональны стоимости. */
export function defaultCaseItems(c: CaseDef): { unit_id: string; weight: number }[] {
  const out: { unit_id: string; weight: number }[] = [];
  for (const [rarity, pct] of Object.entries(c.tiers) as [Rarity, number][]) {
    const units = UNITS.filter((u) => u.rarity === rarity);
    const inv = units.map((u) => 1 / u.value);
    const sum = inv.reduce((a, b) => a + b, 0);
    units.forEach((u, i) => {
      out.push({ unit_id: u.id, weight: Math.max(1, Math.round((pct * 1000 * inv[i]) / sum)) });
    });
  }
  return out;
}

export function niceRound(n: number): number {
  if (n < 50) return Math.max(5, Math.round(n / 5) * 5);
  const mag = Math.pow(10, Math.floor(Math.log10(n)) - 1);
  return Math.round(n / mag) * mag;
}

// ---- Color Dice ----
export const DICE_COLORS = [
  { id: 'red', label: 'Красный', hex: '#ef4444', weight: 30 },
  { id: 'blue', label: 'Синий', hex: '#3b82f6', weight: 26 },
  { id: 'green', label: 'Зелёный', hex: '#22c55e', weight: 20 },
  { id: 'purple', label: 'Фиолетовый', hex: '#a855f7', weight: 13 },
  { id: 'gold', label: 'Золотой', hex: '#fbbf24', weight: 8 },
  { id: 'rainbow', label: 'Радужный', hex: '#f472b6', weight: 3 },
] as const;
export type DiceColorId = (typeof DICE_COLORS)[number]['id'];
export const DICE_RTP = 0.94;
export const DICE_MIN_BET = 10;
export const DICE_MAX_BET = 100000;

// ---- Прочие константы экономики ----
export const START_GEMS = 1000;
export const LOGIN_BONUS = 50;
export const DAILY_REWARDS = [100, 150, 200, 300, 400, 600, 1000];
export const SELL_RATE = 0.75;
export const SHOP_MARKUP = 1.6;
export const UPGRADE_RTP = 0.93;
export const UPGRADE_MAX_CHANCE = 0.9;
export const UPGRADE_MIN_CHANCE = 0.005;
export const MAX_OPEN_COUNT = 10;
export const WIN_BONUS_RATE = 0.05; // бонус гемов победителю батла от взноса
