import { useEffect, useState } from 'react';
import { get, fmtFull } from '../api';
import { useStore } from '../store';
import { Avatar, Empty, Gem, UnitImg } from '../ui/bits';

const TABS = [['richest', '💎 Богатейшие'], ['wins', '⚔️ Победы'], ['collections', '🎒 Коллекции'], ['upgrades', '⚡ Апгрейды']] as const;

export function Leaderboard() {
  const { user, unitMap } = useStore();
  const [tab, setTab] = useState<(typeof TABS)[number][0]>('richest');
  const [d, setD] = useState<any>(null);
  useEffect(() => { get('/api/leaderboard').then(setD); }, []);
  const list: any[] = d?.[tab] ?? [];
  return (
    <div className="page">
      <h1>Лидерборд</h1>
      <div className="chips">{TABS.map(([k, l]) => <button key={k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{l}</button>)}</div>
      {!d ? <div className="spinner" /> : list.length === 0 ? <Empty>Пока никого нет</Empty> : (
        <div className="list lb">{list.map((r, i) => (
          <div key={i} className={`list-row lb-row ${r.nick === user.nick ? 'me' : ''} top${i < 3 ? i + 1 : 0}`}>
            <span className="rank">{i < 3 ? ['🥇', '🥈', '🥉'][i] : i + 1}</span>
            <span className="lb-nick"><Avatar unit={r.avatar_unit ?? null} nick={r.nick} size={32} /> {r.nick}</span>
            {tab === 'upgrades' && <span className="lb-unit"><UnitImg id={r.unit_id} /> {unitMap.get(r.unit_id)?.name} · {(r.chance * 100).toFixed(1)}%</span>}
            {tab === 'wins' && <span className="muted">{r.losses} пор.</span>}
            <b>{tab === 'wins' ? fmtFull(r.score) : <Gem n={r.score} full />}</b>
          </div>
        ))}</div>
      )}
    </div>
  );
}
