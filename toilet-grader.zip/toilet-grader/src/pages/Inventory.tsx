import { useMemo, useState } from 'react';
import { post, fmt } from '../api';
import { useStore } from '../store';
import { Btn, Empty, Gem, Modal, UnitCard, UnitImg, useAsync } from '../ui/bits';
import { sfx } from '../sound';
import { WithdrawModal } from './Withdraw';

export function Inventory() {
  const { inventory, unitMap, catalog, go, toast, setGems, refreshInventory, refresh } = useStore();
  const { busy, run } = useAsync();
  const [rar, setRar] = useState('all'); const [q, setQ] = useState(''); const [sort, setSort] = useState('value-desc');
  const [wd, setWd] = useState<{ unit?: string } | null>(null);
  const [sel, setSel] = useState<Record<string, number>>({}); const [detail, setDetail] = useState<string | null>(null);

  const list = useMemo(() => {
    let l = inventory.filter((i) => (rar === 'all' || unitMap.get(i.unit_id)!.rarity === rar) && unitMap.get(i.unit_id)!.name.toLowerCase().includes(q.toLowerCase()));
    const U = (i: { unit_id: string }) => unitMap.get(i.unit_id)!;
    const ro = (i: { unit_id: string }) => catalog.rarities.find((r) => r.id === U(i).rarity)!.order;
    l = [...l].sort((a, b) => ({
      'value-desc': U(b).value - U(a).value, 'value-asc': U(a).value - U(b).value, 'rarity': ro(b) - ro(a) || U(b).value - U(a).value,
      'name': U(a).name.localeCompare(U(b).name), 'qty': b.qty - a.qty,
    } as Record<string, number>)[sort]);
    return l;
  }, [inventory, rar, q, sort, unitMap, catalog]);

  const total = inventory.reduce((a, i) => a + unitMap.get(i.unit_id)!.value * i.qty, 0);
  const selItems = Object.entries(sel).filter(([, n]) => n > 0).map(([unit_id, qty]) => ({ unit_id, qty }));
  const selValue = selItems.reduce((a, i) => a + unitMap.get(i.unit_id)!.value * i.qty, 0);
  const toggle = (id: string, max: number) => { sfx.click(); setSel((s) => ({ ...s, [id]: ((s[id] ?? 0) + 1) > max ? 0 : (s[id] ?? 0) + 1 })); };

  const sell = (items: { unit_id: string; qty: number }[]) => run(async () => {
    const r = await post<{ gained: number; balance: number }>('/api/inventory/sell', { items });
    sfx.coin(); toast(`Продано за ${fmt(r.gained)} гемов`, 'ok'); setGems(r.balance); setSel({}); setDetail(null); await refreshInventory();
  });
  const toUpgrader = () => { sessionStorage.setItem('tg_up_sel', JSON.stringify(selItems)); go('upgrader'); };
  const setAvatar = (id: string) => run(async () => { await post('/api/profile/avatar', { unit_id: id }); toast('Аватар обновлён', 'ok'); await refresh(); setDetail(null); });
  const det = detail ? inventory.find((i) => i.unit_id === detail) : null;

  return (
    <div className="page">
      <div className="row between"><h1>Инвентарь</h1><Btn kind="gold" onClick={() => setWd({})}>📤 Вывод</Btn></div>
      <div className="muted">Юнитов: {inventory.reduce((a, i) => a + i.qty, 0)} · Стоимость коллекции: <Gem n={total} full /></div>
      <div className="toolbar">
        <input placeholder="Поиск по названию" value={q} onChange={(e) => setQ(e.target.value)} />
        <select value={sort} onChange={(e) => setSort(e.target.value)}>
          <option value="value-desc">Дороже → дешевле</option><option value="value-asc">Дешевле → дороже</option><option value="rarity">По редкости</option><option value="name">По названию</option><option value="qty">По количеству</option>
        </select>
      </div>
      <div className="chips">
        <button className={rar === 'all' ? 'on' : ''} onClick={() => setRar('all')}>Все</button>
        {catalog.rarities.map((r) => <button key={r.id} className={rar === r.id ? 'on' : ''} style={{ '--rc': r.color } as any} onClick={() => setRar(r.id)}>{r.id}</button>)}
      </div>
      {list.length === 0 ? <Empty>{inventory.length ? 'Ничего не найдено' : 'Инвентарь пуст — откройте первый кейс!'}</Empty> : (
        <div className="grid units">
          {list.map((i) => (
            <UnitCard key={i.unit_id} id={i.unit_id} qty={i.qty} selected={!!sel[i.unit_id]} badge={sel[i.unit_id] ? `✓ ${sel[i.unit_id]}` : undefined} onClick={() => toggle(i.unit_id, i.qty)}>
              <button className="info-btn" onClick={(e) => { e.stopPropagation(); setDetail(i.unit_id); }} aria-label="Подробнее">ⓘ</button>
            </UnitCard>
          ))}
        </div>
      )}
      {selItems.length > 0 && (
        <div className="sel-bar">
          <span>Выбрано: {selItems.reduce((a, i) => a + i.qty, 0)} · <Gem n={selValue} /></span>
          <Btn onClick={toUpgrader}>⚡ В апгрейдер</Btn>
          <Btn kind="ghost" busy={busy} onClick={() => sell(selItems)}>Продать за {fmt(Math.floor(selValue * catalog.config.sellRate))}</Btn>
          <Btn kind="ghost" onClick={() => setSel({})}>Сброс</Btn>
        </div>
      )}
      {wd && <WithdrawModal unitId={wd.unit} onClose={() => setWd(null)} />}
      {det && (() => {
        const u = unitMap.get(det.unit_id)!;
        return (
          <Modal onClose={() => setDetail(null)}>
            <div className="center"><div className="big-img"><UnitImg id={u.id} /></div><h2 style={{ color: catalog.rarities.find((r) => r.id === u.rarity)!.color }}>{u.name}</h2>
              <p className="muted">{u.desc}</p>
              <div className="tags"><span className="tag">{u.rarity}</span><span className="tag"><Gem n={u.value} full /></span><span className="tag">×{det.qty}</span></div>
              <div className="row center">
                <Btn kind="ghost" busy={busy} onClick={() => sell([{ unit_id: u.id, qty: 1 }])}>Продать 1 за {fmt(Math.floor(u.value * catalog.config.sellRate))}</Btn>
                {det.qty > 1 && <Btn kind="ghost" busy={busy} onClick={() => sell([{ unit_id: u.id, qty: det.qty }])}>Продать все ×{det.qty}</Btn>}
                <Btn kind="ghost" busy={busy} onClick={() => setAvatar(u.id)}>Сделать аватаром</Btn>
                <Btn kind="gold" onClick={() => { setDetail(null); setWd({ unit: u.id }); }}>📤 Вывод</Btn>
              </div>
            </div>
          </Modal>
        );
      })()}
    </div>
  );
}
