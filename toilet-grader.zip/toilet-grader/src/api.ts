export class ApiError extends Error { status: number; constructor(m: string, s: number) { super(m); this.status = s; } }

const uid = () => (crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).slice(2) + Date.now().toString(36));

export async function api<T = any>(method: 'GET' | 'POST', path: string, body?: unknown): Promise<T> {
  const headers: Record<string, string> = {};
  if (method === 'POST') { headers['Content-Type'] = 'application/json'; headers['X-Request-Id'] = uid(); }
  const res = await fetch(path, { method, headers, body: method === 'POST' ? JSON.stringify(body ?? {}) : undefined, credentials: 'same-origin' });
  let data: any = null;
  try { data = await res.json(); } catch { /* пусто */ }
  if (!res.ok) throw new ApiError(data?.error || `Ошибка ${res.status}`, res.status);
  return data as T;
}
export const get = <T = any>(p: string) => api<T>('GET', p);
export const post = <T = any>(p: string, b?: unknown) => api<T>('POST', p, b);
export const fmt = (n: number) => {
  if (n >= 1e9) return (n / 1e9).toFixed(n >= 1e10 ? 0 : 1).replace(/\.0$/, '') + 'B';
  if (n >= 1e6) return (n / 1e6).toFixed(n >= 1e7 ? 0 : 1).replace(/\.0$/, '') + 'M';
  if (n >= 1e4) return (n / 1e3).toFixed(n >= 1e5 ? 0 : 1).replace(/\.0$/, '') + 'K';
  return String(Math.round(n));
};
export const fmtFull = (n: number) => n.toLocaleString('ru-RU');
export const pct = (x: number) => (x >= 0.1 ? (x * 100).toFixed(1) : x >= 0.001 ? (x * 100).toFixed(2) : (x * 100).toFixed(3)).replace(/\.?0+$/, '') + '%';
export const timeAgo = (ts: number) => new Date(ts).toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
