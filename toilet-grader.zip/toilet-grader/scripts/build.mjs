// Сборка клиента (React + TypeScript → public/app.js) через esbuild.
import { build, context } from 'esbuild';
const opts = {
  entryPoints: ['src/main.tsx'],
  bundle: true, outfile: 'public/app.js', format: 'iife', target: 'es2020',
  jsx: 'automatic', minify: !process.argv.includes('--watch'), sourcemap: false,
  define: { 'process.env.NODE_ENV': '"production"' }, logLevel: 'info',
};
if (process.argv.includes('--watch')) { const ctx = await context(opts); await ctx.watch(); }
else await build(opts);
